/* Web4Tools image tool - runs entirely in your browser; images never leave your device. */
(function(){'use strict';
const $=id=>document.getElementById(id);
const file=$('file'),drop=$('drop');
let canvas=$('canvas');
if(!canvas){canvas=document.createElement('canvas');canvas.id='canvas';(document.querySelector('.preview')||document.querySelector('.tool')).appendChild(canvas)}
const ctx=canvas.getContext('2d');
let img=null,srcName='image';
const num=(id,d)=>{const e=$(id);const v=e?parseFloat(e.value):NaN;return Number.isFinite(v)?v:d};
function say(m){let s=$('status');if(!s){s=document.createElement('p');s.id='status';s.className='muted';(document.querySelector('.actions')||document.querySelector('.tool')).after(s)}s.textContent=m}
drop.addEventListener('click',()=>file.click());
drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('drag')});
drop.addEventListener('dragleave',()=>drop.classList.remove('drag'));
drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('drag');const f=e.dataTransfer.files[0];if(f)loadFile(f)});
file.addEventListener('change',()=>{if(file.files[0])loadFile(file.files[0])});
function loadFile(f){
  if(!f.type.startsWith('image/')){say('Please choose an image file.');return}
  srcName=f.name.replace(/\.[^.]+$/,'')||'image';
  const u=URL.createObjectURL(f),im=new Image();
  im.onload=()=>{img=im;URL.revokeObjectURL(u);onLoad();render();say(im.naturalWidth+' x '+im.naturalHeight+' px loaded.')};
  im.onerror=()=>say('Could not read that image.');
  im.src=u;
}
function save(type,quality,suffix){
  if(!img){say('Choose an image first.');return}
  const ext={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[type]||'png';
  canvas.toBlob(b=>{if(!b){say('This browser cannot export '+ext.toUpperCase()+'.');return}
    const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=srcName+'-'+suffix+'.'+ext;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)},type,quality);
}
function bind(ids,fn){ids.forEach(i=>{const e=$(i);if(e)e.addEventListener('input',fn)})}
let onLoad=()=>{},render=()=>{};

const fmt=$('format'),q=$('quality');
render=()=>{if(!img)return;canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;
  if(fmt.value==='image/jpeg'){ctx.fillStyle='#fff';ctx.fillRect(0,0,canvas.width,canvas.height)}else ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.drawImage(img,0,0)};
fmt.addEventListener('change',render);
$('download').addEventListener('click',()=>save(fmt.value,parseFloat(q.value),'converted'));

})();
