/* Web4Tools image tool - runs entirely in your browser; images never leave your device. */
(function(){'use strict';
const $=id=>document.getElementById(id);
const file=$('file'),drop=$('drop');
let canvas=$('canvas');
if(!canvas){canvas=document.createElement('canvas');canvas.id='canvas';(document.querySelector('.preview')||document.querySelector('.tool')).appendChild(canvas)}
const ctx=canvas.getContext('2d');
let img=null,srcName='image';
const num=(id,d)=>{const e=$(id);const v=e?parseFloat(e.value):NaN;return Number.isFinite(v)?v:d};
function say(m){let s=$('status');if(!s){s=document.createElement('p');s.id='status';s.className='muted';(document.querySelector('.actions')||document.querySelector('.tool')).after(s)}s.textContent=m}
drop.addEventListener('click',()=>file.click());
drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('drag')});
drop.addEventListener('dragleave',()=>drop.classList.remove('drag'));
drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('drag');const f=e.dataTransfer.files[0];if(f)loadFile(f)});
file.addEventListener('change',()=>{if(file.files[0])loadFile(file.files[0])});
function loadFile(f){
  if(!f.type.startsWith('image/')){say('Please choose an image file.');return}
  srcName=f.name.replace(/\.[^.]+$/,'')||'image';
  const u=URL.createObjectURL(f),im=new Image();
  im.onload=()=>{img=im;URL.revokeObjectURL(u);onLoad();render();say(im.naturalWidth+' x '+im.naturalHeight+' px loaded.')};
  im.onerror=()=>say('Could not read that image.');
  im.src=u;
}
function save(type,quality,suffix){
  if(!img){say('Choose an image first.');return}
  const ext={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[type]||'png';
  canvas.toBlob(b=>{if(!b){say('This browser cannot export '+ext.toUpperCase()+'.');return}
    const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=srcName+'-'+suffix+'.'+ext;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000)},type,quality);
}
function bind(ids,fn){ids.forEach(i=>{const e=$(i);if(e)e.addEventListener('input',fn)})}
let onLoad=()=>{},render=()=>{};

render=()=>{if(!img)return;
  const s=num('scale',1),w=Math.round(img.naturalWidth*s),h=Math.round(img.naturalHeight*s);
  if(w*h>100000000){say('That size is too large for the browser.');return}
  canvas.width=w;canvas.height=h;ctx.imageSmoothingQuality='high';
  ctx.filter='contrast('+(100+num('contrast',0))+'%)';ctx.drawImage(img,0,0,w,h);ctx.filter='none';
  const amt=num('sharp',0);if(amt>0)sharpen(amt)};
function sharpen(a){
  const w=canvas.width,h=canvas.height,src=ctx.getImageData(0,0,w,h),dst=ctx.createImageData(w,h),s=src.data,d=dst.data;
  const k=[0,-a,0,-a,1+4*a,-a,0,-a,0];
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;
    if(x===0||y===0||x===w-1||y===h-1){d[i]=s[i];d[i+1]=s[i+1];d[i+2]=s[i+2];d[i+3]=s[i+3];continue}
    for(let c=0;c<3;c++){let v=0,n=0;for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++)v+=s[((y+dy)*w+x+dx)*4+c]*k[n++];d[i+c]=v<0?0:v>255?255:v}
    d[i+3]=s[i+3]}
  ctx.putImageData(dst,0,0)}
bind(['contrast','sharp'],render);$('scale').addEventListener('change',render);
$('download').addEventListener('click',()=>save('image/png',1,'enhanced'));

})();
