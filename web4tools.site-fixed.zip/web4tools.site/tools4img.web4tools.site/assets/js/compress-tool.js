// DRAWER

    const appDrawerBtn =
      document.getElementById("appDrawerBtn");

    const closeDrawerBtn =
      document.getElementById("closeDrawerBtn");

    const drawerOverlay =
      document.getElementById("drawerOverlay");

    appDrawerBtn?.addEventListener("click", () => {
      drawerOverlay.classList.add("active");
    });

    closeDrawerBtn?.addEventListener("click", () => {
      drawerOverlay.classList.remove("active");
    });

    drawerOverlay?.addEventListener("click", (e) => {
      if (e.target === drawerOverlay) {
        drawerOverlay.classList.remove("active");
      }
    });

    // IMAGE TOOL

    const uploadArea =
      document.getElementById("uploadArea");

    const fileInput =
      document.getElementById("fileInput");

    const compressBtn =
      document.getElementById("compressBtn");

    const originalPreview =
      document.getElementById("originalPreview");

    const compressedPreview =
      document.getElementById("compressedPreview");

    const originalSize =
      document.getElementById("originalSize");

    const compressedSize =
      document.getElementById("compressedSize");

    const reduction =
      document.getElementById("reduction");

    const downloadBtn =
      document.getElementById("downloadBtn");

    let selectedFile = null;
    let compressedFile = null;

    uploadArea.addEventListener("click", () => {
      fileInput.click();
    });

    uploadArea.addEventListener("dragover", (e) => {
      e.preventDefault();
      uploadArea.classList.add("dragover");
    });

    uploadArea.addEventListener("dragleave", () => {
      uploadArea.classList.remove("dragover");
    });

    uploadArea.addEventListener("drop", (e) => {
      e.preventDefault();

      uploadArea.classList.remove("dragover");

      const file = e.dataTransfer.files[0];

      if (file) {
        handleFile(file);
      }
    });

    fileInput.addEventListener("change", (e) => {
      const file = e.target.files[0];

      if (file) {
        handleFile(file);
      }
    });

    function handleFile(file) {
      selectedFile = file;

      compressBtn.disabled = false;

      const reader = new FileReader();

      reader.onload = (e) => {
        originalPreview.innerHTML =
          `<img src="${e.target.result}">`;
      };

      reader.readAsDataURL(file);

      originalSize.textContent =
        formatSize(file.size);
    }

    compressBtn.addEventListener("click", async () => {
      if (!selectedFile) return;

      compressBtn.innerHTML =
        `<i class="fas fa-spinner fa-spin"></i> Compressing...`;

      compressBtn.disabled = true;

      try {
        const options = {
          maxSizeMB: parseFloat(
            document.getElementById("maxSize").value
          ),

          maxWidthOrHeight: parseInt(
            document.getElementById("maxWidth").value
          ),

          initialQuality: parseFloat(
            document.getElementById("quality").value
          ),

          useWebWorker: true,
        };

        compressedFile =
          await imageCompression(
            selectedFile,
            options
          );

        const compressedUrl =
          URL.createObjectURL(compressedFile);

        compressedPreview.innerHTML =
          `<img src="${compressedUrl}">`;

        compressedSize.textContent =
          formatSize(compressedFile.size);

        const saved =
          (
            ((selectedFile.size -
              compressedFile.size) /
              selectedFile.size) *
            100
          ).toFixed(0);

        reduction.textContent =
          `${saved}% smaller`;

        downloadBtn.style.display = "block";

        downloadBtn.onclick = () => {
          const a = document.createElement("a");

          a.href = compressedUrl;

          a.download =
            `compressed-${selectedFile.name}`;

          a.click();
        };

      } catch (err) {
        alert("Compression failed.");
      }

      compressBtn.innerHTML =
        `<i class="fas fa-bolt"></i> Compress Images`;

      compressBtn.disabled = false;
    });

    function formatSize(bytes) {
      if (bytes < 1024)
        return bytes + " B";

      if (bytes < 1024 * 1024)
        return (bytes / 1024).toFixed(1) + " KB";

      return (
        (bytes / (1024 * 1024)).toFixed(1) + " MB"
      );
    }
