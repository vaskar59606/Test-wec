/* Web4Tools batch image tool - runs entirely in your browser. */
(function(){'use strict';
const $=id=>document.getElementById(id),file=$('file'),drop=$('drop');
let status=$('status');
if(!status){status=document.createElement('p');status.id='status';status.className='muted';$('run').after(status)}
drop.addEventListener('click',()=>file.click());
drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('drag')});
drop.addEventListener('dragleave',()=>drop.classList.remove('drag'));
drop.addEventListener('drop',e=>{e.preventDefault();drop.classList.remove('drag');const dt=new DataTransfer();[...e.dataTransfer.files].filter(f=>f.type.startsWith('image/')).forEach(f=>dt.items.add(f));file.files=dt.files;file.dispatchEvent(new Event('change'))});
file.addEventListener('change',()=>{status.textContent=file.files.length+' file(s) selected.'});
function load(f){return new Promise((res,rej)=>{const u=URL.createObjectURL(f),im=new Image();im.onload=()=>{URL.revokeObjectURL(u);res(im)};im.onerror=()=>{URL.revokeObjectURL(u);rej(new Error('bad image'))};im.src=u})}
$('run').addEventListener('click',async()=>{
  if(!file.files.length){status.textContent='Choose images first.';return}
  const type=$('format').value,ext={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[type],max=parseFloat($('w').value)||1600;
  let done=0,failed=0;status.textContent='Processing...';
  for(const f of file.files){
    try{const im=await load(f),s=Math.min(1,max/im.naturalWidth),c=document.createElement('canvas');
      c.width=Math.max(1,Math.round(im.naturalWidth*s));c.height=Math.max(1,Math.round(im.naturalHeight*s));
      const x=c.getContext('2d');if(type==='image/jpeg'){x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height)}
      x.drawImage(im,0,0,c.width,c.height);
      const b=await new Promise(r=>c.toBlob(r,type,.9));if(!b)throw 0;
      const a=document.createElement('a');a.href=URL.createObjectURL(b);a.download=f.name.replace(/\.[^.]+$/,'')+'-web4tools.'+ext;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(a.href),4000);done++;
      await new Promise(r=>setTimeout(r,250));
    }catch(e){failed++}
    status.textContent='Processed '+done+' of '+file.files.length+'...';
  }
  status.textContent='Done: '+done+' file(s)'+(failed?', '+failed+' failed.':'.');
});
})();
