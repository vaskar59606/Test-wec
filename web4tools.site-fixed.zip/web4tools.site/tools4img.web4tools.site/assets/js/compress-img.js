const fileInput = document.getElementById('fileInput');
        const compressBtn = document.getElementById('compressBtn');

        const originalBox = document.getElementById('originalBox');
        const compressedBox = document.getElementById('compressedBox');

        const originalSize = document.getElementById('originalSize');
        const compressedSize = document.getElementById('compressedSize');

        const reduction = document.getElementById('reduction');

        const quality = document.getElementById('quality');
        const qualityValue = document.getElementById('qualityValue');

        const downloadBtn = document.getElementById('downloadBtn');

        let selectedFile = null;
        let compressedBlob = null;

        quality.addEventListener('input', () => {
            qualityValue.textContent = quality.value + '%';
        });

        fileInput.addEventListener('change', (e) => {

            const file = e.target.files[0];

            if(!file) return;

            selectedFile = file;

            compressBtn.disabled = false;

            originalSize.textContent = formatSize(file.size);

            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);

            originalBox.innerHTML = '';
            originalBox.appendChild(img);
        });

        compressBtn.addEventListener('click', async () => {

            if(!selectedFile) return;

            const maxWidth =
                parseInt(document.getElementById('maxWidth').value);

            const qualityValueNum =
                parseInt(quality.value) / 100;

            const img = new Image();

            img.src = URL.createObjectURL(selectedFile);

            await img.decode();

            let width = img.width;
            let height = img.height;

            if(width > maxWidth || height > maxWidth){

                if(width > height){
                    height *= maxWidth / width;
                    width = maxWidth;
                }else{
                    width *= maxWidth / height;
                    height = maxWidth;
                }
            }

            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');

            canvas.width = width;
            canvas.height = height;

            ctx.drawImage(img,0,0,width,height);

            compressedBlob = await new Promise(resolve => {
                canvas.toBlob(
                    resolve,
                    'image/jpeg',
                    qualityValueNum
                );
            });

            const compressedImg = document.createElement('img');

            compressedImg.src =
                URL.createObjectURL(compressedBlob);

            compressedBox.innerHTML = '';
            compressedBox.appendChild(compressedImg);

            compressedSize.textContent =
                formatSize(compressedBlob.size);

            const reduced =
                (
                    (
                        (selectedFile.size - compressedBlob.size)
                        / selectedFile.size
                    ) * 100
                ).toFixed(1);

            reduction.textContent = reduced + '%';

            downloadBtn.style.display = 'block';
        });

        downloadBtn.addEventListener('click', () => {

            if(!compressedBlob) return;

            const a = document.createElement('a');

            a.href = URL.createObjectURL(compressedBlob);

            a.download =
                'compressed-' + selectedFile.name;

            a.click();
        });

        function formatSize(bytes){

            if(bytes < 1024)
                return bytes + ' B';

            if(bytes < 1024 * 1024)
                return (bytes / 1024).toFixed(1) + ' KB';

            return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
        }
