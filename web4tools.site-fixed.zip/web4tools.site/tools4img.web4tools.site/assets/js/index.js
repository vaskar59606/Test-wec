const drawerBtn=document.getElementById('appDrawerBtn');
const overlay=document.getElementById('drawerOverlay');
const closeDrawerBtn=document.getElementById('closeDrawerBtn');

function openDrawer(){
overlay.classList.add('active');
document.body.style.overflow='hidden';
}

function closeDrawer(){
overlay.classList.remove('active');
document.body.style.overflow='';
}

drawerBtn?.addEventListener('click',openDrawer);

closeDrawerBtn?.addEventListener('click',closeDrawer);

overlay?.addEventListener('click',(e)=>{
if(e.target===overlay){
closeDrawer();
}
});

document.addEventListener('keydown',(e)=>{
if(e.key==='Escape' && overlay.classList.contains('active')){
closeDrawer();
}
});
