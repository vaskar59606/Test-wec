/* Web4Tools AdSense helper.
   Keep genuine AdSense units visible; hide empty visual placeholders.
   This script does not create fake ads or invent publisher/ad-slot IDs. */
(function () {
  "use strict";
  function auditAdSlots() {
    var selectors = ".w4t-ad-slot, .ad-slot, .adsense-slot, [data-adsense-slot]";
    document.querySelectorAll(selectors).forEach(function (slot) {
      var realUnit = slot.querySelector("ins.adsbygoogle");
      if (realUnit) {
        slot.hidden = false;
        slot.style.display = "";
        slot.removeAttribute("data-adsense-placeholder");
        slot.setAttribute("aria-label", "Advertisement");
      } else {
        slot.hidden = true;
        slot.style.display = "none";
        slot.setAttribute("data-adsense-placeholder", "true");
        slot.setAttribute("aria-hidden", "true");
      }
    });
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", auditAdSlots, { once: true });
  } else {
    auditAdSlots();
  }
}());
