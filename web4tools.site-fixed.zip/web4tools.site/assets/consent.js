/* Web4Tools cookie/ads notice - identical on every site. Choice is stored in localStorage ("w4t-consent"). */
(function () {
  "use strict";
  var KEY = "w4t-consent", v = null;
  try { v = localStorage.getItem(KEY); } catch (e) {}
  // Declined: ask Google for non-personalized ads only.
  function apply(choice) {
    if (choice === "declined") { (window.adsbygoogle = window.adsbygoogle || []).requestNonPersonalizedAds = 1; }
  }
  apply(v);
  if (v) return;
  function show() {
    var b = document.createElement("div");
    b.setAttribute("role", "dialog"); b.setAttribute("aria-label", "Cookie notice");
    b.style.cssText = "position:fixed;left:12px;right:12px;bottom:12px;max-width:640px;margin:0 auto;z-index:2147483100;background:#fff;color:#202124;border:1px solid #dadce0;border-radius:14px;box-shadow:0 8px 30px rgba(0,0,0,.2);padding:14px 16px;font:14px/1.45 system-ui,-apple-system,'Segoe UI',Roboto,Arial,sans-serif;display:flex;gap:12px;align-items:center;flex-wrap:wrap";
    b.innerHTML = '<span style="flex:1 1 260px">We use cookies for ads (Google AdSense) and to keep the site working. Your files never leave your browser. See our <a href="https://web4tools.site/privacy-policy.html" style="color:#1a73e8">Privacy Policy</a>.</span>' +
      '<span style="display:flex;gap:8px"><button type="button" data-c="declined" style="border:1px solid #dadce0;background:#fff;color:#202124;border-radius:10px;padding:8px 14px;cursor:pointer;font:inherit">Essential only</button>' +
      '<button type="button" data-c="accepted" style="border:0;background:#1a73e8;color:#fff;border-radius:10px;padding:8px 14px;cursor:pointer;font:inherit;font-weight:600">Accept</button></span>';
    b.addEventListener("click", function (e) {
      var c = e.target.getAttribute && e.target.getAttribute("data-c"); if (!c) return;
      try { localStorage.setItem(KEY, c); } catch (x) {}
      apply(c); b.remove();
    });
    document.body.appendChild(b);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", show); else show();
})();
