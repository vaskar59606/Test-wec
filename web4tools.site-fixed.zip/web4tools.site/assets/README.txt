SHARED SITE SCRIPTS
===================
Every site (web4tools.site and its subdomains) is a separate document root, so each has its OWN COPY of
these files. They must stay byte-identical:

  /assets/app-drawer.js   one app drawer for all sites (6 apps; fixed look, not themed per site)
  /assets/consent.js      cookie / ads notice

To change the drawer: edit one copy, then copy it to /assets/ of root, tools4pdf, tools4img, tools4dev,
finance and weccer. Every page loads it with:
  <script src="/assets/app-drawer.js" defer></script>
The drawer opens from any element matching [data-drawer], #appDrawerBtn, #drawerBtn, .app-drawer-btn or
.drawerbtn; pages with none get a button added automatically.
To add an app: add one entry to SITES in app-drawer.js (and copy to every site).
