/*!
 * Web4Tools app drawer - ONE canonical file, identical on every site.
 * Do not edit per-site copies; edit this file and copy it to each site's /assets/app-drawer.js.
 * Fixed look (not themed per site) so the drawer is the same everywhere.
 */
(function () {
  "use strict";
  if (window.__W4T_APP_DRAWER__) return;
  window.__W4T_APP_DRAWER__ = true;

  var SITES = [
    { name: "Web4Tools", icon: "fa-window-restore", color: "#2563eb", url: "https://web4tools.site/", host: "web4tools.site" },
    { name: "Tools4PDF", icon: "fa-file-pdf", color: "#f97316", url: "https://tools4pdf.web4tools.site/", host: "tools4pdf.web4tools.site" },
    { name: "Tools4Img", icon: "fa-image", color: "#e5484d", url: "https://tools4img.web4tools.site/", host: "tools4img.web4tools.site" },
    { name: "Tools4Dev", icon: "fa-code", color: "#8b5cf6", url: "https://tools4dev.web4tools.site/", host: "tools4dev.web4tools.site" },
    { name: "Finance", icon: "fa-chart-pie", color: "#14b8a6", url: "https://finance.web4tools.site/", host: "finance.web4tools.site" },
    { name: "WECCER", icon: "fa-indian-rupee-sign", color: "#6a5acd", url: "https://weccer.web4tools.site/", host: "weccer.web4tools.site" }
  ];

  var TRIGGERS = "[data-drawer], #appDrawerBtn, #drawerBtn, .app-drawer-btn, .drawerbtn";
  var ID = "w4t-app-drawer";
  var isOpen = false;
  var activeTrigger = null;

  function ensureFontAwesome() {
    if (document.querySelector('link[href*="font-awesome"], link[href*="fontawesome"], link[data-w4t-fa]')) return;
    var l = document.createElement("link");
    l.rel = "stylesheet";
    l.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css";
    l.setAttribute("data-w4t-fa", "1");
    document.head.appendChild(l);
  }

  function injectStyles() {
    if (document.getElementById(ID + "-css")) return;
    var s = document.createElement("style");
    s.id = ID + "-css";
    s.textContent =
      "#" + ID + "{position:fixed;z-index:2147483000;width:min(390px,calc(100vw - 12px));max-height:calc(100vh - 12px);overflow:auto;background:#fff;color:#202124;border:1px solid #dadce0;border-radius:20px;box-shadow:0 12px 40px rgba(0,0,0,.18),0 2px 8px rgba(0,0,0,.1);font-family:system-ui,-apple-system,'Segoe UI',Roboto,Arial,sans-serif;opacity:0;visibility:hidden;transform:translateY(-6px) scale(.98);pointer-events:none;transition:opacity .16s ease,transform .16s ease,visibility .16s}" +
      "#" + ID + ".w4t-open{opacity:1;visibility:visible;transform:none;pointer-events:auto}" +
      "#" + ID + " *{box-sizing:border-box}" +
      "#" + ID + " .w4t-head{display:flex;align-items:center;justify-content:space-between;padding:14px 12px 8px 20px}" +
      "#" + ID + " .w4t-title{font-size:15px;font-weight:600}" +
      "#" + ID + " .w4t-close{width:36px;height:36px;border:0;border-radius:50%;background:transparent;color:#5f6368;cursor:pointer;font-size:16px;display:grid;place-items:center}" +
      "#" + ID + " .w4t-close:hover{background:#f1f3f4;color:#202124}" +
      "#" + ID + " .w4t-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;padding:8px 12px 18px}" +
      "#" + ID + " .w4t-site{min-width:0;color:#202124;text-decoration:none;border-radius:12px;padding:12px 5px 10px;display:flex;flex-direction:column;align-items:center;gap:6px}" +
      "#" + ID + " .w4t-site:hover,#" + ID + " .w4t-site:focus-visible{background:#f1f3f4;outline:none}" +
      "#" + ID + " .w4t-site.w4t-current{background:#eef3fd}" +
      "#" + ID + " .w4t-icon{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;color:#fff;font-size:20px;box-shadow:0 1px 2px rgba(0,0,0,.08)}" +
      "#" + ID + " .w4t-name{font-size:12px;line-height:1.25;text-align:center;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}" +
      "#" + ID + " .w4t-foot{border-top:1px solid #dadce0;padding:11px 20px 13px;text-align:center;font-size:11px;color:#5f6368}" +
      "#" + ID + " .w4t-foot a{color:#1a73e8;text-decoration:none;font-weight:500}" +
      ".w4t-auto-btn{display:inline-grid;place-items:center;width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:inherit;cursor:pointer;font-size:18px;margin-left:8px}" +
      ".w4t-auto-btn:hover{background:rgba(128,128,128,.15)}";
    document.head.appendChild(s);
  }

  function build() {
    if (document.getElementById(ID)) return;
    injectStyles();
    var d = document.createElement("div");
    d.id = ID;
    d.setAttribute("role", "dialog");
    d.setAttribute("aria-label", "Web4Tools apps");
    var here = location.hostname.replace(/^www\./, "");
    var cells = SITES.map(function (s) {
      var cur = s.host === here ? " w4t-current" : "";
      return '<a class="w4t-site' + cur + '" href="' + s.url + '" title="' + s.name + '"' + (cur ? ' aria-current="true"' : "") + '>' +
        '<span class="w4t-icon" style="background:' + s.color + '"><i class="fas ' + s.icon + '" aria-hidden="true"></i></span>' +
        '<span class="w4t-name">' + s.name + "</span></a>";
    }).join("");
    d.innerHTML =
      '<div class="w4t-head"><div class="w4t-title">Web4Tools apps</div>' +
      '<button class="w4t-close" type="button" aria-label="Close"><i class="fas fa-times" aria-hidden="true"></i></button></div>' +
      '<div class="w4t-grid">' + cells + "</div>" +
      '<div class="w4t-foot"><a href="https://web4tools.site/">Web4Tools</a> &middot; all tools, free in your browser</div>';
    document.body.appendChild(d);
    d.querySelector(".w4t-close").addEventListener("click", close);
  }

  function position(trigger) {
    var d = document.getElementById(ID);
    if (!d) return;
    var r = trigger.getBoundingClientRect();
    var w = Math.min(390, window.innerWidth - 12);
    d.style.width = w + "px";
    var h = d.offsetHeight || 260;
    var left = Math.max(6, Math.min(r.right - w, window.innerWidth - w - 6));
    var top = r.bottom + 8;
    if (top + h > window.innerHeight - 6) top = Math.max(6, r.top - h - 8);
    d.style.left = Math.round(left) + "px";
    d.style.top = Math.round(top) + "px";
  }

  function open(trigger) {
    build();
    var d = document.getElementById(ID);
    activeTrigger = trigger;
    position(trigger);
    d.classList.add("w4t-open");
    isOpen = true;
    trigger.setAttribute("aria-expanded", "true");
  }

  function close() {
    var d = document.getElementById(ID);
    if (d) d.classList.remove("w4t-open");
    if (activeTrigger) {
      activeTrigger.setAttribute("aria-expanded", "false");
      if (activeTrigger.focus) activeTrigger.focus();
    }
    isOpen = false;
    activeTrigger = null;
  }

  // Capture phase: beats any legacy per-page drawer handlers so only this drawer opens.
  document.addEventListener("click", function (e) {
    var t = e.target.closest ? e.target.closest(TRIGGERS) : null;
    if (t) {
      e.preventDefault();
      e.stopPropagation();
      if (e.stopImmediatePropagation) e.stopImmediatePropagation();
      if (isOpen && activeTrigger === t) close(); else { if (isOpen) close(); open(t); }
      return;
    }
    var d = document.getElementById(ID);
    if (isOpen && d && !d.contains(e.target)) close();
  }, true);

  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && isOpen) close(); });
  window.addEventListener("resize", function () { if (isOpen && activeTrigger) position(activeTrigger); });
  window.addEventListener("scroll", function () { if (isOpen && activeTrigger) position(activeTrigger); }, true);

  // Pages with no drawer button get one, so the drawer is available on every page.
  function addButtonIfMissing() {
    if (document.querySelector(TRIGGERS)) return;
    var host = document.querySelector("header .nav, header .container, header.top, header, .navbar, nav");
    var b = document.createElement("button");
    b.type = "button";
    b.className = "w4t-auto-btn";
    b.id = "appDrawerBtn";
    b.setAttribute("aria-label", "Open app drawer");
    b.setAttribute("aria-expanded", "false");
    b.title = "Web4Tools apps";
    b.innerHTML = '<i class="fas fa-th" aria-hidden="true"></i>';
    if (host) {
      var spacer = host.matches && host.matches("header.top") ? host.querySelector("#themebtn") : null;
      if (spacer) host.insertBefore(b, spacer); else host.appendChild(b);
    } else {
      b.style.cssText = "position:fixed;top:10px;right:10px;z-index:2147482000;background:#fff;color:#202124;box-shadow:0 1px 6px rgba(0,0,0,.2)";
      document.body.appendChild(b);
    }
  }

  function init() {
    ensureFontAwesome();
    injectStyles();
    document.querySelectorAll(TRIGGERS).forEach(function (el) {
      el.setAttribute("aria-expanded", "false");
      if (!el.getAttribute("aria-label")) el.setAttribute("aria-label", "Open app drawer");
    });
    addButtonIfMissing();
    // Single-page apps (WECCER) re-render their header: re-check once the DOM settles.
    if (document.getElementById("view")) setTimeout(addButtonIfMissing, 600);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
})();
