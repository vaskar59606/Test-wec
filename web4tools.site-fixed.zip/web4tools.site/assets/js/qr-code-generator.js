(function(){
  'use strict';
  const type=document.getElementById('qrType'), fields=document.getElementById('qrFields'), preview=document.getElementById('qrPreview');
  const size=document.getElementById('qrSize'), dark=document.getElementById('qrDark'), light=document.getElementById('qrLight');
  const generate=document.getElementById('generateQr'), clear=document.getElementById('clearQr'), download=document.getElementById('downloadQr'), print=document.getElementById('printQr'), status=document.getElementById('qrStatus');
  let currentText='', currentCanvas=null;
  const configs={
    url:[['url','Website URL','https://example.com','url']],
    text:[['text','Text','Enter your text here','textarea']],
    email:[['email','Email address','name@example.com','email'],['subject','Subject','Hello','text'],['body','Message','Your message','textarea']],
    phone:[['phone','Phone number','+911234567890','tel']],
    wifi:[['ssid','Wi-Fi network name','My Wi-Fi','text'],['password','Wi-Fi password','Password','text'],['security','Security','WPA','select'],['hidden','Hidden network','','checkbox']]
  };
  function fieldHtml(item){const [id,label,placeholder,kind]=item;if(kind==='textarea')return `<div class="field-group"><label for="${id}">${label}</label><textarea id="${id}" rows="4" placeholder="${placeholder}"></textarea></div>`;if(kind==='select')return `<div class="field-group"><label for="${id}">${label}</label><select id="${id}"><option value="WPA">WPA/WPA2</option><option value="WEP">WEP</option><option value="nopass">No password</option></select></div>`;if(kind==='checkbox')return `<div class="field-group"><label><input id="${id}" type="checkbox"> Hidden network</label></div>`;return `<div class="field-group"><label for="${id}">${label}</label><input id="${id}" type="${kind}" placeholder="${placeholder}"></div>`}
  function renderFields(){fields.innerHTML=configs[type.value].map(fieldHtml).join('');fields.querySelectorAll('input,textarea,select').forEach(el=>el.addEventListener('input',generateQr));}
  function value(id){const el=document.getElementById(id);return el?.type==='checkbox'?el.checked:(el?.value||'').trim()}
  function buildText(){switch(type.value){case'url':return value('url');case'text':return value('text');case'email':return `mailto:${value('email')}?subject=${encodeURIComponent(value('subject'))}&body=${encodeURIComponent(value('body'))}`;case'phone':return `tel:${value('phone')}`;case'wifi':return `WIFI:T:${value('security')};S:${value('ssid')};P:${value('password')};H:${value('hidden')?'true':'false'};;`;default:return''}}
  function generateQr(){const text=buildText();if(!text){status.textContent='Enter some information first.';return}if(typeof QRCode==='undefined'){status.textContent='QR library could not load. Check your internet connection and try again.';return}preview.innerHTML='';new QRCode(preview,{text,width:Number(size.value),height:Number(size.value),colorDark:dark.value,colorLight:light.value,correctLevel:QRCode.CorrectLevel.M});currentText=text;setTimeout(()=>{currentCanvas=preview.querySelector('canvas');download.disabled=!currentCanvas;print.disabled=!currentCanvas;status.textContent='QR code generated successfully.'},50)}
  function clearQr(){renderFields();preview.innerHTML='<div class="empty-preview"><i class="fas fa-qrcode"></i><span>Your QR code will appear here</span></div>';currentText='';currentCanvas=null;download.disabled=true;print.disabled=true;status.textContent=''}
  download.addEventListener('click',()=>{if(!currentCanvas)return;const a=document.createElement('a');a.download='web4tools-qr-code.png';a.href=currentCanvas.toDataURL('image/png');a.click()});
  print.addEventListener('click',()=>{if(!currentCanvas)return;const win=window.open('','_blank','width=700,height=700');if(!win)return;win.document.write(`<title>Web4Tools QR Code</title><body style="font-family:Arial;text-align:center;padding:40px"><img src="${currentCanvas.toDataURL('image/png')}" alt="QR Code"><p>${currentText.replace(/</g,'&lt;').replace(/>/g,'&gt;')}</p><script>window.onload=()=>window.print()<\/script></body>`);win.document.close()});
  type.addEventListener('change',()=>{renderFields();generateQr()});[size,dark,light].forEach(el=>el.addEventListener('change',generateQr));generate.addEventListener('click',generateQr);clear.addEventListener('click',clearQr);renderFields();
})();
