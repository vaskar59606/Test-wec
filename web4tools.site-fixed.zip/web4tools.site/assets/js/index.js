// filtering logic
    const filterTags = document.querySelectorAll('.filter-tag');
    const toolCards = document.querySelectorAll('.tool-card');
    
    function filterTools(category) {
        toolCards.forEach(card => {
            const cardCat = card.getAttribute('data-cat');
            if (category === 'all' || cardCat === category) {
                card.classList.remove('hidden-card');
            } else {
                card.classList.add('hidden-card');
            }
        });
        filterTags.forEach(tag => {
            const tagFilter = tag.getAttribute('data-filter');
            if (tagFilter === category) {
                tag.classList.add('active');
            } else {
                tag.classList.remove('active');
            }
        });
    }

    filterTags.forEach(tag => {
        tag.addEventListener('click', () => {
            const filterValue = tag.getAttribute('data-filter');
            filterTools(filterValue);
        });
    });

    // App drawer logic
    const drawerBtn = document.getElementById('appDrawerBtn');
    const overlay = document.getElementById('drawerOverlay');
    const closeDrawerBtn = document.getElementById('closeDrawerBtn');

    function openDrawer() {
        overlay.classList.add('active');
        overlay.setAttribute('aria-hidden', 'false');
        drawerBtn.setAttribute('aria-expanded', 'true');
        document.body.style.overflow = 'hidden';
        closeDrawerBtn.focus();
    }
    function closeDrawer() {
        overlay.classList.remove('active');
        overlay.setAttribute('aria-hidden', 'true');
        drawerBtn.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
    }

    drawerBtn?.addEventListener('click', openDrawer);
    closeDrawerBtn?.addEventListener('click', closeDrawer);
    overlay?.addEventListener('click', (e) => {
        if (e.target === overlay) closeDrawer();
    });
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && overlay.classList.contains('active')) closeDrawer();
    });
