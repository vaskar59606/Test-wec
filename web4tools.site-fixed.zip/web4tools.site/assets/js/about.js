const overlay=document.getElementById('drawerOverlay');
const openBtn=document.getElementById('appDrawerBtn');
const closeBtn=document.getElementById('closeDrawerBtn');
function openDrawer(){overlay.classList.add('active');document.body.style.overflow='hidden'}
function closeDrawer(){overlay.classList.remove('active');document.body.style.overflow=''}
openBtn?.addEventListener('click',openDrawer);
closeBtn?.addEventListener('click',closeDrawer);
overlay?.addEventListener('click',e=>{if(e.target===overlay)closeDrawer()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay.classList.contains('active'))closeDrawer()});
