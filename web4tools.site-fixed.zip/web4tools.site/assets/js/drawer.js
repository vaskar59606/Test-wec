(function(){
  const btn=document.getElementById("appDrawerBtn");
  const overlay=document.getElementById("drawerOverlay");
  const close=document.getElementById("closeDrawerBtn");
  if(!btn||!overlay||!close) return;
  const setOpen=(open)=>{
    overlay.classList.toggle("active",open);
    overlay.setAttribute("aria-hidden",String(!open));
    btn.setAttribute("aria-expanded",String(open));
    document.body.style.overflow=open?"hidden":"";
  };
  btn?.addEventListener("click",()=>setOpen(!overlay.classList.contains("active")));
  close.addEventListener("click",()=>setOpen(false));
  overlay?.addEventListener("click",e=>{if(e.target===overlay)setOpen(false);});
  document.addEventListener("keydown",e=>{if(e.key==="Escape")setOpen(false);});
  overlay.querySelectorAll('[data-disabled="true"]').forEach(a=>a.addEventListener("click",e=>e.preventDefault()));
})();
