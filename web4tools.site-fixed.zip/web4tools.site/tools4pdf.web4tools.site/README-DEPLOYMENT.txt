Tools4PDF — deployment and maintenance notes
================================================

Project type
- Static HTML/CSS/JavaScript website. No npm install or build command is required.
- Keep this folder as the document root when deploying to Apache/cPanel.

Structure
- index.html, Style.css, Script.js: homepage
- Pages/: individual tools and informational pages
- assets/: shared app drawer, consent notice, AdSense helper, common styles/scripts (see /assets/README.txt)
- Pages/Assets/: page-specific tool assets (merge, compression, organizer)
- sitemap.xml, robots.txt, .htaccess: SEO and Apache configuration

Important conventions
- Shared assets use root-relative URLs such as /assets/app-drawer.js and /assets/favicon.png.
- Tool-specific assets remain under Pages/Assets/ and are linked relative to their HTML page.
- Do not remove the AdSense publisher script or change its publisher ID unless you control that AdSense account. Visual ad placeholders do not guarantee a live ad unit; real ad slots require approved slot IDs.

Local preview
1. Open a terminal in this directory.
2. Run: python -m http.server 8000
3. Visit http://localhost:8000/

Deployment checks
- Upload the contents of this folder to the website document root, not the enclosing ZIP folder.
- Test every tool in a current desktop and mobile browser.
- Browser-side PDF operations can use significant memory on large files. Test large and encrypted files separately.
- External CDN libraries require internet access.
- Confirm all live sitemap URLs return HTTP 200 after deployment.
