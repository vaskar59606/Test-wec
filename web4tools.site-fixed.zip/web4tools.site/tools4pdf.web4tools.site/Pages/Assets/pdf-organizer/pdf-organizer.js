(function () {
    "use strict";

    if (window.pdfjsLib) {
        pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
    }

    const { PDFDocument, degrees } = window.PDFLib || {};
    const fileInput = document.getElementById("fileInput");
    const dropzone = document.getElementById("dropzone");
    const browseBtn = document.getElementById("browseBtn");
    const addMoreBtn = document.getElementById("addMoreBtn");
    const workspace = document.getElementById("workspace");
    const pageGrid = document.getElementById("pageGrid");
    const fileCount = document.getElementById("fileCount");
    const pageCount = document.getElementById("pageCount");
    const selectedCount = document.getElementById("selectedCount");
    const selectAllBtn = document.getElementById("selectAllBtn");
    const rotateLeftBtn = document.getElementById("rotateLeftBtn");
    const rotateRightBtn = document.getElementById("rotateRightBtn");
    const deleteBtn = document.getElementById("deleteBtn");
    const clearBtn = document.getElementById("clearBtn");
    const sortPagesSelect = document.getElementById("sortPages");
    const exportBtn = document.getElementById("exportBtn");
    const progress = document.getElementById("progress");
    const progressFill = document.getElementById("progressFill");
    const progressLabel = document.getElementById("progressLabel");
    const progressPercent = document.getElementById("progressPercent");
    const status = document.getElementById("status");
    const downloadBox = document.getElementById("downloadBox");
    const downloadLink = document.getElementById("downloadLink");

    const state = {
        sources: [],
        pages: [],
        selected: new Set(),
        dragId: null,
        lastSelectedIndex: null,
        url: null,
        rendering: false
    };

    function setStatus(message, type) {
        status.textContent = message || "";
        status.className = "status" + (message ? " show " + (type || "info") : "");
    }

    function setProgress(value, label) {
        const pct = Math.max(0, Math.min(100, Math.round(value)));
        progress.classList.add("active");
        progressFill.style.width = pct + "%";
        progressPercent.textContent = pct + "%";
        progressLabel.textContent = label || "Working…";
    }

    function hideProgress() {
        progress.classList.remove("active");
        progressFill.style.width = "0%";
        progressPercent.textContent = "0%";
    }

    function selectedPages() {
        return state.pages.filter(p => state.selected.has(p.id));
    }

    function updateStats() {
        fileCount.textContent = state.sources.length;
        pageCount.textContent = state.pages.length;
        selectedCount.textContent = state.selected.size;

        const hasSelection = state.selected.size > 0;
        rotateLeftBtn.disabled = !hasSelection;
        rotateRightBtn.disabled = !hasSelection;
        deleteBtn.disabled = !hasSelection;
        exportBtn.disabled = state.pages.length === 0;
        selectAllBtn.innerHTML = state.selected.size === state.pages.length && state.pages.length ?
            '<i class="fas fa-square-minus"></i> Clear Selection' :
            '<i class="fas fa-check-double"></i> Select All';
    }

    function clampRotation(value) {
        let r = value % 360;
        if (r < 0) r += 360;
        return r;
    }

    function selectCard(id, event) {
        const index = state.pages.findIndex(p => p.id === id);
        if (index < 0) return;

        if (event && event.shiftKey && state.lastSelectedIndex !== null) {
            const start = Math.min(state.lastSelectedIndex, index);
            const end = Math.max(state.lastSelectedIndex, index);
            state.selected.clear();
            for (let i = start; i <= end; i++) state.selected.add(state.pages[i].id);
        } else if (event && (event.ctrlKey || event.metaKey)) {
            if (state.selected.has(id)) state.selected.delete(id);
            else state.selected.add(id);
            state.lastSelectedIndex = index;
        } else {
            if (!state.selected.has(id) || state.selected.size > 1) {
                state.selected.clear();
                state.selected.add(id);
            } else {
                state.selected.clear();
            }
            state.lastSelectedIndex = index;
        }
        renderGrid();
        updateStats();
    }

    async function renderThumbnail(pageItem, canvas) {
        try {
            const source = state.sources[pageItem.sourceIndex];
            if (!source || !source.pdfjsDoc) return;
            const pdfPage = await source.pdfjsDoc.getPage(pageItem.pageIndex + 1);
            const baseViewport = pdfPage.getViewport({ scale: 1 });
            const targetWidth = 170;
            const scale = Math.min(targetWidth / baseViewport.width, 0.52);
            const viewport = pdfPage.getViewport({ scale });
            const rot = clampRotation(pageItem.rotation);
            const rotated = pdfPage.getViewport({ scale, rotation: rot });
            canvas.width = Math.ceil(rotated.width);
            canvas.height = Math.ceil(rotated.height);
            await pdfPage.render({ canvasContext: canvas.getContext("2d", { alpha: false }), viewport: rotated }).promise;
        } catch (err) {
            const ctx = canvas.getContext("2d");
            canvas.width = 160;
            canvas.height = 210;
            ctx.fillStyle = "#f8fafc";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.fillStyle = "#94a3b8";
            ctx.font = "14px Inter, sans-serif";
            ctx.textAlign = "center";
            ctx.fillText("Preview unavailable", 80, 100);
        }
    }

    function renderGrid() {
        pageGrid.innerHTML = "";
        if (!state.pages.length) {
            pageGrid.innerHTML = '<div class="empty-grid">No pages to organize. Add a PDF to begin.</div>';
            updateStats();
            return;
        }

        const fragment = document.createDocumentFragment();
        const cards = [];

        state.pages.forEach((item, index) => {
            const card = document.createElement("article");
            card.className = "page-card" + (state.selected.has(item.id) ? " selected" : "");
            card.draggable = true;
            card.dataset.id = item.id;
            card.dataset.index = String(index);
            card.setAttribute("aria-label", `Position ${index + 1}, ${item.fileName}, original PDF page ${item.originalPage + 1}`);

            const thumbWrap = document.createElement("div");
            thumbWrap.className = "thumb-wrap";

            const canvas = document.createElement("canvas");
            canvas.setAttribute("aria-label", `Preview of ${item.fileName}, original PDF page ${item.originalPage + 1}`);
            canvas.width = 170;
            canvas.height = 220;
            thumbWrap.appendChild(canvas);

            // Original identity: NUMBER ONLY. It never changes after reordering.
            const pageBadge = document.createElement("span");
            pageBadge.className = "page-badge";
            pageBadge.textContent = String(item.originalPage + 1);
            pageBadge.title = "Original page number";
            thumbWrap.appendChild(pageBadge);

            const positionBadge = document.createElement("span");
            positionBadge.className = "position-badge";
            positionBadge.textContent = `Position ${index + 1}`;
            positionBadge.title = "Current position in the output PDF";
            thumbWrap.appendChild(positionBadge);

            const selectedBadge = document.createElement("span");
            selectedBadge.className = "selected-badge";
            selectedBadge.innerHTML = '<i class="fas fa-check"></i>';
            thumbWrap.appendChild(selectedBadge);

            const actionRow = document.createElement("div");
            actionRow.className = "card-actions";

            const title = document.createElement("div");
            title.className = "page-title";
            title.title = item.fileName;
            title.textContent = `${item.fileName} • Page ${item.originalPage + 1}`;

            const mini = document.createElement("div");
            mini.className = "mini-actions";
            mini.innerHTML = `
                <button class="icon-btn" type="button" data-act="left" aria-label="Rotate page left"><i class="fas fa-rotate-left"></i></button>
                <button class="icon-btn" type="button" data-act="right" aria-label="Rotate page right"><i class="fas fa-rotate-right"></i></button>
                <button class="icon-btn delete" type="button" data-act="delete" aria-label="Delete page"><i class="fas fa-trash"></i></button>`;
            actionRow.append(title, mini);
            card.append(thumbWrap, actionRow);
            fragment.appendChild(card);
            cards.push({ card, canvas, item });

            card.addEventListener("click", (event) => {
                if (event.target.closest("button")) return;
                selectCard(item.id, event);
            });
            card.addEventListener("dblclick", (event) => {
                if (event.target.closest("button")) return;
                rotateItems([item.id], 90);
            });

            card.addEventListener("dragstart", (event) => {
                state.dragId = item.id;
                card.classList.add("dragging");
                if (event.dataTransfer) {
                    event.dataTransfer.effectAllowed = "move";
                    event.dataTransfer.setData("text/plain", item.id);
                }
            });
            card.addEventListener("dragend", () => {
                state.dragId = null;
                card.classList.remove("dragging");
                document.querySelectorAll(".drop-target").forEach(el => el.classList.remove("drop-target"));
            });
            card.addEventListener("dragover", (event) => {
                event.preventDefault();
                if (state.dragId && state.dragId !== item.id) card.classList.add("drop-target");
                if (event.dataTransfer) event.dataTransfer.dropEffect = "move";
            });
            card.addEventListener("dragleave", () => card.classList.remove("drop-target"));
            card.addEventListener("drop", (event) => {
                event.preventDefault();
                card.classList.remove("drop-target");
                const sourceId = state.dragId || event.dataTransfer?.getData("text/plain");
                if (!sourceId || sourceId === item.id) return;
                movePageBefore(sourceId, item.id);
            });

            mini.querySelectorAll("button").forEach(btn => btn.addEventListener("click", (event) => {
                event.stopPropagation();
                const act = btn.dataset.act;
                if (act === "left") rotateItems([item.id], -90);
                if (act === "right") rotateItems([item.id], 90);
                if (act === "delete") deletePages([item.id]);
            }));
        });

        // Append everything before starting PDF.js rendering. This prevents
        // detached canvases from being rendered while the grid is rebuilding.
        pageGrid.appendChild(fragment);
        updateStats();

        // Render a few thumbnails at a time. This is much more reliable on
        // mobile devices with large PDFs and after repeated drag/reorder actions.
        let cursor = 0;
        const renderBatch = async () => {
            const batch = cards.slice(cursor, cursor + 3);
            cursor += batch.length;
            await Promise.all(batch.map(({ item, canvas }) => renderThumbnail(item, canvas)));
            if (cursor < cards.length) {
                if ("requestIdleCallback" in window) {
                    requestIdleCallback(renderBatch, { timeout: 120 });
                } else {
                    setTimeout(renderBatch, 20);
                }
            }
        };
        renderBatch();
    }


    function sortPages(mode) {
        if (!state.pages.length) return;

        if (mode === "manual") {
            // Manual order is already the current order. Nothing to change.
            renderGrid();
            return;
        }

        const originalOrder = [...state.pages];
        if (mode === "original") {
            state.pages.sort((a, b) =>
                a.sourceNumber - b.sourceNumber ||
                a.originalPage - b.originalPage ||
                a.id.localeCompare(b.id)
            );
        } else if (mode === "pdf") {
            state.pages.sort((a, b) =>
                a.sourceNumber - b.sourceNumber ||
                a.pageIndex - b.pageIndex ||
                a.id.localeCompare(b.id)
            );
        } else if (mode === "filename") {
            state.pages.sort((a, b) =>
                a.fileName.localeCompare(b.fileName, undefined, { numeric: true, sensitivity: "base" }) ||
                a.sourceNumber - b.sourceNumber ||
                a.originalPage - b.originalPage
            );
        }

        const changed = state.pages.some((p, i) => p.id !== originalOrder[i]?.id);
        state.lastSelectedIndex = null;
        renderGrid();
        setStatus(changed ? "Pages sorted. The number on each thumbnail remains its original page number." : "Pages are already in that order.", "info");
    }

    function movePageBefore(sourceId, targetId) {
        const sourceIndex = state.pages.findIndex(p => p.id === sourceId);
        let targetIndex = state.pages.findIndex(p => p.id === targetId);
        if (sourceIndex < 0 || targetIndex < 0 || sourceIndex === targetIndex) return;
        const [moved] = state.pages.splice(sourceIndex, 1);
        targetIndex = state.pages.findIndex(p => p.id === targetId);
        state.pages.splice(targetIndex, 0, moved);
        state.lastSelectedIndex = state.pages.findIndex(p => p.id === sourceId);
        renderGrid();
        setStatus("Page order updated.", "info");
    }

    function rotateItems(ids, delta) {
        const wanted = new Set(ids);
        state.pages.forEach(p => {
            if (wanted.has(p.id)) p.rotation = clampRotation(p.rotation + delta);
        });
        renderGrid();
    }

    function deletePages(ids) {
        const wanted = new Set(ids);
        if (!wanted.size) return;
        state.pages = state.pages.filter(p => !wanted.has(p.id));
        ids.forEach(id => state.selected.delete(id));
        state.lastSelectedIndex = null;
        renderGrid();
        setStatus(`${ids.length} page${ids.length === 1 ? "" : "s"} removed.`, "success");
        if (!state.pages.length) {
            state.sources.forEach(s => s.pdfjsDoc?.destroy?.());
            state.sources = [];
            workspace.classList.remove("active");
            dropzone.style.display = "flex";
        }
    }

    async function addFiles(fileList) {
        const files = Array.from(fileList || []).filter(f => f && (f.type === "application/pdf" || f.name.toLowerCase().endsWith(".pdf")));
        if (!files.length) {
            setStatus("Please choose one or more PDF files.", "error");
            return;
        }
        if (!window.pdfjsLib || !PDFDocument) {
            setStatus("PDF libraries could not be loaded. Check your internet connection and reload the page.", "error");
            return;
        }

        dropzone.style.display = "none";
        workspace.classList.add("active");
        state.rendering = true;
        setStatus("Loading PDF pages…", "info");
        hideDownload();

        let loadedAny = false;
        for (const file of files) {
            try {
                const buffer = await file.arrayBuffer();
                const sourceIndex = state.sources.length;
                const pdfjsDoc = await pdfjsLib.getDocument({ data: buffer.slice(0) }).promise;
                const pdfLibDoc = await PDFDocument.load(buffer, { ignoreEncryption: false });
                const source = { file, buffer, pdfjsDoc, pdfLibDoc };
                state.sources.push(source);
                loadedAny = true;

                for (let i = 0; i < pdfjsDoc.numPages; i++) {
                    state.pages.push({
                        sourceNumber: sourceIndex + 1,
                        id: `${Date.now()}-${sourceIndex}-${i}-${Math.random().toString(16).slice(2)}`,
                        sourceIndex,
                        pageIndex: i,
                        originalPage: i,
                        fileName: file.name,
                        rotation: 0
                    });
                    if ((i + 1) % 8 === 0 || i === pdfjsDoc.numPages - 1) {
                        setProgress(((i + 1) / pdfjsDoc.numPages) * 100, `Reading ${file.name}: page ${i + 1} of ${pdfjsDoc.numPages}`);
                    }
                }
            } catch (err) {
                console.error(err);
                setStatus(`Could not load ${file.name}. The PDF may be password-protected, damaged, or unsupported.`, "error");
            }
        }

        state.rendering = false;
        hideProgress();
        updateStats();
        renderGrid();
        setStatus(loadedAny ? "PDF pages loaded. The black label keeps each page’s original identity; the red label shows its current output position." : "No PDF was loaded.", loadedAny ? "success" : "error");
        fileInput.value = "";
    }

    function hideDownload() {
        downloadBox.classList.remove("active");
        if (state.url) {
            URL.revokeObjectURL(state.url);
            state.url = null;
        }
        downloadLink.removeAttribute("href");
    }

    async function exportPdf() {
        if (!state.pages.length || state.rendering) return;
        if (!PDFDocument || !degrees) {
            setStatus("PDF export library is unavailable. Reload the page and try again.", "error");
            return;
        }

        exportBtn.disabled = true;
        setStatus("Building your organized PDF…", "info");
        hideDownload();
        setProgress(4, "Preparing output PDF…");

        try {
            const output = await PDFDocument.create();
            const sourceCopyCache = new Map();
            const total = state.pages.length;

            for (let i = 0; i < total; i++) {
                const item = state.pages[i];
                const source = state.sources[item.sourceIndex];
                if (!source) continue;

                let copied;
                if (!sourceCopyCache.has(item.sourceIndex)) {
                    sourceCopyCache.set(item.sourceIndex, []);
                }
                const cached = sourceCopyCache.get(item.sourceIndex);

                if (!cached[item.pageIndex]) {
                    const pages = await output.copyPages(source.pdfLibDoc, [item.pageIndex]);
                    cached[item.pageIndex] = pages[0];
                }

                copied = cached[item.pageIndex];
                const baseRotation = (source.pdfLibDoc.getPage(item.pageIndex).getRotation()?.angle || 0);
                copied.setRotation(degrees((baseRotation + item.rotation) % 360));
                output.addPage(copied);
                setProgress(10 + ((i + 1) / total) * 80, `Adding page ${i + 1} of ${total}…`);
            }

            const bytes = await output.save({ useObjectStreams: true });
            const blob = new Blob([bytes], { type: "application/pdf" });
            state.url = URL.createObjectURL(blob);
            downloadLink.href = state.url;
            downloadLink.download = "organized-pdf.pdf";
            downloadBox.classList.add("active");
            setProgress(100, "Done");
            setStatus("Your organized PDF is ready to download.", "success");
            setTimeout(hideProgress, 700);
        } catch (err) {
            console.error(err);
            setStatus("Export failed. One of the PDFs may be encrypted or unsupported by the browser PDF engine.", "error");
            hideProgress();
        } finally {
            updateStats();
        }
    }

    function clearAll() {
        state.sources.forEach(s => s.pdfjsDoc?.destroy?.());
        state.sources = [];
        state.pages = [];
        state.selected.clear();
        state.lastSelectedIndex = null;
        hideDownload();
        workspace.classList.remove("active");
        dropzone.style.display = "flex";
        pageGrid.innerHTML = "";
        hideProgress();
        setStatus("", "info");
        updateStats();
    }

    browseBtn.addEventListener("click", () => fileInput.click());
    addMoreBtn.addEventListener("click", () => fileInput.click());
    fileInput.addEventListener("change", event => addFiles(event.target.files));

    ["dragenter", "dragover"].forEach(type => dropzone.addEventListener(type, event => {
        event.preventDefault();
        dropzone.classList.add("dragover");
    }));
    ["dragleave", "drop"].forEach(type => dropzone.addEventListener(type, event => {
        event.preventDefault();
        dropzone.classList.remove("dragover");
    }));
    dropzone.addEventListener("drop", event => addFiles(event.dataTransfer.files));
    dropzone.addEventListener("keydown", event => {
        if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            fileInput.click();
        }
    });

    selectAllBtn.addEventListener("click", () => {
        if (state.selected.size === state.pages.length) state.selected.clear();
        else state.pages.forEach(p => state.selected.add(p.id));
        renderGrid();
    });

    rotateLeftBtn.addEventListener("click", () => rotateItems(Array.from(state.selected), -90));
    rotateRightBtn.addEventListener("click", () => rotateItems(Array.from(state.selected), 90));
    deleteBtn.addEventListener("click", () => deletePages(Array.from(state.selected)));
    clearBtn.addEventListener("click", clearAll);
    sortPagesSelect.addEventListener("change", () => sortPages(sortPagesSelect.value));
    exportBtn.addEventListener("click", exportPdf);

    document.addEventListener("keydown", event => {
        if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "a" && state.pages.length) {
            if (document.activeElement === fileInput) return;
            event.preventDefault();
            state.pages.forEach(p => state.selected.add(p.id));
            renderGrid();
        }
        if (event.key === "Delete" && state.selected.size && !["INPUT", "TEXTAREA"].includes(document.activeElement?.tagName)) {
            event.preventDefault();
            deletePages(Array.from(state.selected));
        }
    });

    const drawerOverlay = document.getElementById("drawerOverlay");
    const appDrawerBtn = document.getElementById("appDrawerBtn");
    const closeDrawerBtn = document.getElementById("closeDrawerBtn");

    function closeDrawer() {
        drawerOverlay.classList.remove("active");
        drawerOverlay.setAttribute("aria-hidden", "true");
    }
    appDrawerBtn?.addEventListener("click", () => {
        drawerOverlay.classList.add("active");
        drawerOverlay.setAttribute("aria-hidden", "false");
    });
    closeDrawerBtn?.addEventListener("click", closeDrawer);
    drawerOverlay?.addEventListener("click", event => {
        if (event.target === drawerOverlay) closeDrawer();
    });
    document.addEventListener("keydown", event => {
        if (event.key === "Escape") closeDrawer();
    });

    window.addEventListener("beforeunload", () => {
        state.sources.forEach(s => s.pdfjsDoc?.destroy?.());
        if (state.url) URL.revokeObjectURL(state.url);
    });

    updateStats();
})();
