(() => {
    "use strict";

    // Configurable browser-side safety limits. Increase only after testing on target devices.
    const MAX_FILES = 50;
    const MAX_FILE_SIZE = 250 * 1024 * 1024;   // 250 MiB per PDF
    const MAX_TOTAL_SIZE = 500 * 1024 * 1024;  // 500 MiB combined
    const OUTPUT_FILENAME = "merged.pdf";

    pdfjsLib.GlobalWorkerOptions.workerSrc =
        "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";

    const $ = (id) => document.getElementById(id);
    const uploadBox = $("uploadBox");
    const pdfInput = $("pdfInput");
    const previewGrid = $("previewGrid");
    const emptyState = $("emptyState");
    const mergeBtn = $("mergeBtn");
    const addBtn = $("addBtn");
    const sortControl = $("sortControl");
    const sortOrder = $("sortOrder");
    const progressDiv = $("progress");
    const fill = $("fill");
    const progressText = $("progressText");
    const progressBar = $("mergeProgressBar");
    const downloadDiv = $("download");
    const statusBox = $("mergeStatus");

    // Canonical array order is always the user's manual order. Alphabetical views never mutate it.
    let pdfFiles = [];
    let sortableInstance = null;
    let renderGeneration = 0;
    let isAddingFiles = false;
    let isMerging = false;
    let currentDownloadUrl = null;

    function formatBytes(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / 1048576).toFixed(1)} MB`;
    }

    function showStatus(message, type = "error") {
        statusBox.textContent = message;
        statusBox.className = `merge-status ${type}`;
        statusBox.hidden = false;
    }

    function clearStatus() {
        statusBox.textContent = "";
        statusBox.hidden = true;
        statusBox.className = "merge-status";
    }

    function setProgress(percent, message) {
        const value = Math.max(0, Math.min(100, Math.round(percent)));
        fill.style.width = `${value}%`;
        progressBar.setAttribute("aria-valuenow", String(value));
        progressText.textContent = message;
    }

    function getTotalSize(files = pdfFiles) {
        return files.reduce((total, item) => total + item.file.size, 0);
    }

    function fileKey(file) {
        return `${file.name}\u0000${file.size}\u0000${file.lastModified}`;
    }

    function updateControls() {
        const hasFiles = pdfFiles.length > 0;
        emptyState.style.display = hasFiles ? "none" : "block";
        previewGrid.style.display = hasFiles ? "grid" : "none";
        addBtn.style.display = hasFiles ? "inline-block" : "none";
        sortControl.style.display = hasFiles ? "flex" : "none";
        mergeBtn.disabled = isMerging || isAddingFiles || pdfFiles.length < 2;
        addBtn.disabled = isMerging || isAddingFiles;
        pdfInput.disabled = isMerging || isAddingFiles;
        sortOrder.disabled = isMerging || isAddingFiles;
        if (!hasFiles) sortOrder.value = "manual";
    }

    function destroySortable() {
        if (sortableInstance) {
            sortableInstance.destroy();
            sortableInstance = null;
        }
    }

    async function createThumbnail(file) {
        let loadingTask;
        let pdf;
        try {
            const buffer = await file.arrayBuffer();
            loadingTask = pdfjsLib.getDocument({
                data: new Uint8Array(buffer),
                isEvalSupported: false
            });
            pdf = await loadingTask.promise;
            const pageCount = pdf.numPages;
            let thumbnail = null;

            try {
                const page = await pdf.getPage(1);

                // Render a higher-resolution thumbnail than the old 0.4 scale.
                // Cap the longest edge to avoid huge canvases for oversized PDF pages.
                const baseViewport = page.getViewport({ scale: 1 });
                const maxThumbnailEdge = 1400;
                const scale = Math.min(1.6, maxThumbnailEdge / Math.max(baseViewport.width, baseViewport.height));
                const viewport = page.getViewport({ scale });
                const canvas = document.createElement("canvas");
                const context = canvas.getContext("2d", { alpha: false });
                if (!context) throw new Error("Canvas rendering is unavailable.");
                canvas.width = Math.ceil(viewport.width);
                canvas.height = Math.ceil(viewport.height);
                context.fillStyle = "#ffffff";
                context.fillRect(0, 0, canvas.width, canvas.height);
                await page.render({ canvasContext: context, viewport }).promise;
                // Higher JPEG quality reduces text and line-art artifacts in small previews.
                thumbnail = canvas.toDataURL("image/jpeg", 0.92);
                page.cleanup();
                canvas.width = 0;
                canvas.height = 0;
            } catch (thumbnailError) {
                // A preview failure should not reject a PDF that PDF.js can otherwise read.
                console.warn(`Thumbnail could not be rendered for ${file.name}:`, thumbnailError);
            }

            return { pages: pageCount, thumbnail };
        } finally {
            if (pdf && typeof pdf.destroy === "function") {
                await pdf.destroy().catch(() => {});
            } else if (loadingTask && typeof loadingTask.destroy === "function") {
                await loadingTask.destroy().catch(() => {});
            }
        }
    }

    function createCard(item) {
        const card = document.createElement("article");
        card.className = "preview-card";
        card.dataset.fileId = item.id;

        const removeBtn = document.createElement("button");
        removeBtn.type = "button";
        removeBtn.className = "preview-remove";
        removeBtn.textContent = "✕";
        removeBtn.setAttribute("aria-label", `Remove ${item.file.name}`);
        removeBtn.title = `Remove ${item.file.name}`;
        removeBtn.disabled = isMerging || isAddingFiles;
        removeBtn.addEventListener("click", () => removeFile(item.id));

        const thumbDiv = document.createElement("div");
        thumbDiv.className = "preview-thumb";
        if (item.thumbnail) {
            const image = document.createElement("img");
            image.src = item.thumbnail;
            image.alt = `First page preview of ${item.file.name}`;
            image.loading = "lazy";
            thumbDiv.appendChild(image);
        } else {
            const placeholder = document.createElement("span");
            placeholder.textContent = "📄";
            placeholder.setAttribute("aria-hidden", "true");
            thumbDiv.appendChild(placeholder);
        }

        const infoDiv = document.createElement("div");
        infoDiv.className = "preview-info";
        const nameDiv = document.createElement("div");
        nameDiv.className = "preview-name";
        nameDiv.textContent = item.file.name;
        nameDiv.title = item.file.name;

        const metaDiv = document.createElement("div");
        metaDiv.className = "preview-meta";
        metaDiv.textContent = `${item.pages} Pages • ${formatBytes(item.file.size)}`;
        infoDiv.append(nameDiv, metaDiv);
        card.append(removeBtn, thumbDiv, infoDiv);
        return card;
    }

    async function renderCards() {
        const generation = ++renderGeneration;
        destroySortable();
        previewGrid.replaceChildren();

        const mode = sortOrder.value;
        let displayFiles = [...pdfFiles];
        if (mode === "az") {
            displayFiles.sort((a, b) =>
                a.file.name.localeCompare(b.file.name, undefined, {
                    numeric: true, sensitivity: "base"
                })
            );
        } else if (mode === "za") {
            displayFiles.sort((a, b) =>
                b.file.name.localeCompare(a.file.name, undefined, {
                    numeric: true, sensitivity: "base"
                })
            );
        }

        for (const item of displayFiles) {
            if (generation !== renderGeneration) return;
            previewGrid.appendChild(createCard(item));
        }

        updateControls();

        if (typeof Sortable !== "undefined" && pdfFiles.length > 1) {
            sortableInstance = new Sortable(previewGrid, {
                animation: 200,
                draggable: ".preview-card",
                handle: ".preview-card",
                disabled: isMerging || isAddingFiles || mode !== "manual",
                onEnd: () => {
                    if (sortOrder.value !== "manual" || isMerging || isAddingFiles) return;
                    const orderedIds = [...previewGrid.querySelectorAll(".preview-card")]
                        .map(card => card.dataset.fileId);
                    const byId = new Map(pdfFiles.map(item => [item.id, item]));
                    if (orderedIds.length === pdfFiles.length && orderedIds.every(id => byId.has(id))) {
                        pdfFiles = orderedIds.map(id => byId.get(id));
                    }
                }
            });
        }
    }

    async function removeFile(id) {
        if (isMerging || isAddingFiles) return;
        const index = pdfFiles.findIndex(item => item.id === id);
        if (index < 0) return;
        pdfFiles.splice(index, 1);
        await renderCards();
        showStatus("PDF removed.", "info");
    }

    async function addFiles(incomingFiles) {
        if (isMerging || isAddingFiles) return;
        clearStatus();

        const files = Array.from(incomingFiles || []);
        if (!files.length) return;

        const rejected = [];
        const accepted = [];
        const existingKeys = new Set(pdfFiles.map(item => fileKey(item.file)));
        let totalSize = getTotalSize();

        for (const file of files) {
            const looksLikePdf = file.type === "application/pdf" ||
                file.name.toLowerCase().endsWith(".pdf");
            if (!looksLikePdf) {
                rejected.push(`${file.name}: not a PDF`);
                continue;
            }
            if (file.size <= 0) {
                rejected.push(`${file.name}: empty file`);
                continue;
            }
            if (file.size > MAX_FILE_SIZE) {
                rejected.push(`${file.name}: exceeds ${formatBytes(MAX_FILE_SIZE)} per-file limit`);
                continue;
            }
            if (existingKeys.has(fileKey(file))) {
                rejected.push(`${file.name}: already added`);
                continue;
            }
            if (pdfFiles.length + accepted.length >= MAX_FILES) {
                rejected.push(`${file.name}: maximum ${MAX_FILES} files reached`);
                continue;
            }
            if (totalSize + file.size > MAX_TOTAL_SIZE) {
                rejected.push(`${file.name}: combined file-size limit (${formatBytes(MAX_TOTAL_SIZE)}) would be exceeded`);
                continue;
            }
            existingKeys.add(fileKey(file));
            totalSize += file.size;
            accepted.push(file);
        }

        if (!accepted.length) {
            showStatus(rejected.length
                ? `No new PDFs were added. ${rejected.slice(0, 5).join("; ")}${rejected.length > 5 ? `; and ${rejected.length - 5} more` : ""}`
                : "Choose one or more PDF files.");
            return;
        }

        isAddingFiles = true;
        updateControls();
        const errors = [];
        let addedCount = 0;

        try {
            for (let i = 0; i < accepted.length; i++) {
                const file = accepted[i];
                showStatus(`Reading ${i + 1} of ${accepted.length}: ${file.name}`, "info");
                try {
                    const details = await createThumbnail(file);
                    pdfFiles.push({
                        id: (typeof crypto !== "undefined" && crypto.randomUUID)
                            ? crypto.randomUUID()
                            : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
                        file,
                        pages: details.pages,
                        thumbnail: details.thumbnail
                    });
                    addedCount++;
                } catch (error) {
                    console.error(`Failed to read ${file.name}:`, error);
                    errors.push(`${file.name}: ${error && error.message ? error.message : "could not read this PDF"}`);
                }
            }
        } finally {
            isAddingFiles = false;
            await renderCards();
        }

        const messages = [];
        if (addedCount) messages.push(`Added ${addedCount} PDF${addedCount === 1 ? "" : "s"}.`);
        if (rejected.length) messages.push(`Skipped: ${rejected.slice(0, 4).join("; ")}${rejected.length > 4 ? `; and ${rejected.length - 4} more` : ""}.`);
        if (errors.length) messages.push(`Could not read: ${errors.slice(0, 4).join("; ")}${errors.length > 4 ? `; and ${errors.length - 4} more` : ""}.`);
        if (messages.length) showStatus(messages.join(" "), errors.length || rejected.length ? "error" : "success");
        else clearStatus();
    }

    async function mergePdfs() {
        if (isMerging || isAddingFiles || pdfFiles.length < 2) return;
        const filesToMerge = pdfFiles.slice(); // Freeze the selected order for this merge.
        if (filesToMerge.length < 2) return;

        isMerging = true;
        clearStatus();
        updateControls();
        if (sortableInstance) sortableInstance.option("disabled", true);
        progressDiv.style.display = "block";
        downloadDiv.style.display = "none";
        setProgress(0, "Preparing merge...");

        try {
            const mergedPdf = await PDFLib.PDFDocument.create();

            for (let i = 0; i < filesToMerge.length; i++) {
                const item = filesToMerge[i];
                setProgress((i / filesToMerge.length) * 100,
                    `Processing ${i + 1} of ${filesToMerge.length}: ${item.file.name}`);

                const buffer = await item.file.arrayBuffer();
                // Do not ignore encryption: that option does not decrypt protected PDFs.
                const sourcePdf = await PDFLib.PDFDocument.load(buffer);
                const copiedPages = await mergedPdf.copyPages(sourcePdf, sourcePdf.getPageIndices());
                for (const page of copiedPages) mergedPdf.addPage(page);

                setProgress(((i + 1) / filesToMerge.length) * 100,
                    `Processed ${i + 1} of ${filesToMerge.length} PDFs.`);
            }

            setProgress(100, "Generating final PDF...");
            const mergedBytes = await mergedPdf.save();
            const blob = new Blob([mergedBytes], { type: "application/pdf" });

            if (currentDownloadUrl) URL.revokeObjectURL(currentDownloadUrl);
            currentDownloadUrl = URL.createObjectURL(blob);

            downloadDiv.replaceChildren();
            const link = document.createElement("a");
            link.href = currentDownloadUrl;
            link.download = OUTPUT_FILENAME;
            const icon = document.createElement("i");
            icon.className = "fas fa-download";
            icon.setAttribute("aria-hidden", "true");
            link.append(icon, document.createTextNode(" Download Merged PDF"));
            downloadDiv.appendChild(link);
            downloadDiv.style.display = "block";
            progressDiv.style.display = "none";
            showStatus(`Merge complete. ${filesToMerge.length} PDFs combined successfully.`, "success");
        } catch (error) {
            console.error("PDF merge failed:", error);
            progressDiv.style.display = "none";
            const message = error && error.message ? error.message : "Unknown PDF processing error.";
            showStatus(
                `Merge failed. One file may be damaged, unsupported, or password-protected. Check the PDF files and try again. Details: ${message}`,
                "error"
            );
        } finally {
            isMerging = false;
            await renderCards();
        }
    }

    // File picker: clear the input value after each selection so the same file can be selected again.
    uploadBox.addEventListener("click", (event) => {
        if (event.target.closest("button") || event.target === pdfInput) return;
        if (!isMerging && !isAddingFiles && pdfFiles.length === 0) pdfInput.click();
    });

    addBtn.addEventListener("click", () => {
        if (!isMerging && !isAddingFiles) pdfInput.click();
    });

    pdfInput.addEventListener("change", async (event) => {
        const selected = Array.from(event.target.files || []);
        event.target.value = "";
        await addFiles(selected);
    });

    uploadBox.addEventListener("dragover", (event) => {
        event.preventDefault();
        if (!isMerging && !isAddingFiles) uploadBox.classList.add("dragging");
    });

    uploadBox.addEventListener("dragleave", (event) => {
        if (!uploadBox.contains(event.relatedTarget)) uploadBox.classList.remove("dragging");
    });

    uploadBox.addEventListener("drop", async (event) => {
        event.preventDefault();
        uploadBox.classList.remove("dragging");
        if (!isMerging && !isAddingFiles) await addFiles(event.dataTransfer.files);
    });

    sortOrder.addEventListener("change", () => {
        if (!isMerging && !isAddingFiles) renderCards();
    });

    mergeBtn.addEventListener("click", mergePdfs);

    // Release the current download URL when leaving the page.
    window.addEventListener("pagehide", () => {
        if (currentDownloadUrl) {
            URL.revokeObjectURL(currentDownloadUrl);
            currentDownloadUrl = null;
        }
    });

    updateControls();
})();
