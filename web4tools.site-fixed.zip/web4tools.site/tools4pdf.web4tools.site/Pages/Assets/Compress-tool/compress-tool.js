/* ============================================================
   Tools4Pdf — Compress PDF tool
   All processing happens client-side. No uploads.

   Features:
   • Optional "recommended target size" — the tool finds the best
     quality that fits, and lowers page resolution if needed.
   • Pre-skip: files already under target are not re-rendered.
   • "Keep smaller" guard: never makes a file worse than original.
   • Live target badges on file cards.
   • Canvas pixel budget for stable mobile performance.
   ============================================================ */

(function () {
  'use strict';

  const CONFIG = {
    maxFiles: 20,
    maxSizeMB: 100,
    previewScale: 0.35,
    renderScale: 1.5,
    yieldEveryPages: 3,

    // Target size search
    targetMinQuality: 0.10,
    targetMaxQuality: 0.92,
    targetMaxQualityIterations: 6,
    targetQualityTolerance: 0.05,

    // Resolution fallback multipliers on the base render scale
    targetScaleSteps: [1, 0.75, 0.55, 0.4],

    // Total pixel budget for cached canvases (~4 bytes/pixel)
    canvasPixelBudget: 60 * 1000 * 1000,

    // Very small targets get a warning
    targetWarnBytes: 50 * 1024,
  };
  const MAX_SIZE_BYTES = CONFIG.maxSizeMB * 1024 * 1024;

  const CDN = {
    pdfjs: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js',
    pdfjsWorker: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
    pdfLib: 'https://unpkg.com/pdf-lib/dist/pdf-lib.min.js',
  };

  /* ---------- DOM refs ---------- */
  const $ = (id) => document.getElementById(id);

  const appDrawerBtn   = $('appDrawerBtn');
  const closeDrawerBtn = $('closeDrawerBtn');
  const drawerOverlay  = $('drawerOverlay');
  const uploadArea     = $('uploadArea');
  const fileInput      = $('fileInput');
  const fileList       = $('fileList');
  const fileListHeader = $('fileListHeader');
  const fileSummary    = $('fileSummary');
  const clearAllBtn    = $('clearAllBtn');
  const processBtn     = $('processBtn');
  const processBtnIcon = $('processBtnIcon');
  const processBtnLabel= $('processBtnLabel');
  const progressArea   = $('progressArea');
  const progressBar    = $('progressBar');
  const progressFill   = $('progressFill');
  const progressText   = $('progressText');
  const results        = $('results');
  const qualitySelect  = $('qualitySelect');
  const targetSize     = $('targetSize');
  const targetUnit     = $('targetUnit');
  const targetHint     = $('targetHint');
  const notice         = $('notice');

  /* ---------- State ---------- */
  let files = [];
  let fileIdCounter = 0;
  let isProcessing = false;
  let noticeTimer = null;
  const previewTargets = new WeakMap();
  const objectUrls = new Set();

  /* ---------- Lazy library loading ---------- */
  let libsPromise = null;

  function loadLibs() {
    if (libsPromise) return libsPromise;
    libsPromise = new Promise((resolve, reject) => {
      let remaining = 2, failed = false;
      const done = () => { if (!failed && --remaining === 0) resolve(); };
      const fail = () => { failed = true; reject(new Error('Failed to load PDF engine')); };

      const s1 = document.createElement('script');
      s1.src = CDN.pdfjs; s1.async = true;
      s1.onload = () => {
        if (window.pdfjsLib) {
          window.pdfjsLib.GlobalWorkerOptions.workerSrc = CDN.pdfjsWorker;
        }
        done();
      };
      s1.onerror = fail;
      document.head.appendChild(s1);

      const s2 = document.createElement('script');
      s2.src = CDN.pdfLib; s2.async = true;
      s2.onload = done; s2.onerror = fail;
      document.head.appendChild(s2);
    });
    return libsPromise;
  }

  /* ---------- Helpers ---------- */
  function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }

  function showNotice(msg, type) {
    notice.textContent = msg;
    notice.className = 'notice' + (type ? ' notice-' + type : '');
    notice.hidden = false;
    clearTimeout(noticeTimer);
    noticeTimer = setTimeout(() => { notice.hidden = true; }, 5000);
  }

  function triggerDownload(url, name) {
    const a = document.createElement('a');
    a.href = url; a.download = name; a.rel = 'noopener';
    document.body.appendChild(a); a.click(); a.remove();
  }

  /* ---------- Target helpers ---------- */
  function getTargetBytes() {
    const raw = parseFloat(targetSize.value);
    if (!isFinite(raw) || raw <= 0) return 0;
    const unit = targetUnit.value;
    return Math.round(raw * (unit === 'MB' ? 1024 * 1024 : 1024));
  }

  function formatTargetLabel(bytes) {
    if (!bytes) return '';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }

  function syncTargetState() {
    const bytes = getTargetBytes();
    qualitySelect.disabled = bytes > 0;

    // Live hint
    if (bytes === 0) {
      targetHint.hidden = true;
    } else if (bytes < CONFIG.targetWarnBytes) {
      targetHint.hidden = false;
      targetHint.textContent = 'Heads up: targets under ' + formatTargetLabel(CONFIG.targetWarnBytes) + ' may look very blurry.';
    } else if (files.length > 0) {
      const totalTarget = bytes * files.length;
      const totalOrig = files.reduce((s, e) => s + e.file.size, 0);
      const ratio = totalOrig > 0 ? Math.round((totalTarget / totalOrig) * 100) : 0;
      targetHint.hidden = false;
      targetHint.textContent =
        'Across ' + files.length + ' file' + (files.length > 1 ? 's' : '') +
        ' · target ≈ ' + ratio + '% of current size';
    } else {
      targetHint.hidden = true;
    }

    renderFiles();   // refresh badges
  }

  targetSize.addEventListener('input', syncTargetState);
  targetUnit.addEventListener('change', syncTargetState);
  targetSize.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !processBtn.disabled) {
      e.preventDefault();
      processAll();
    }
  });

  /* ---------- Drawer ---------- */
  function openDrawer() {
    drawerOverlay.classList.add('active');
    appDrawerBtn.setAttribute('aria-expanded', 'true');
    setTimeout(() => closeDrawerBtn.focus(), 200);
  }
  function closeDrawer() {
    drawerOverlay.classList.remove('active');
    appDrawerBtn.setAttribute('aria-expanded', 'false');
    appDrawerBtn.focus();
  }
  appDrawerBtn?.addEventListener('click', openDrawer);
  closeDrawerBtn?.addEventListener('click', closeDrawer);
  drawerOverlay?.addEventListener('click', (e) => {
    if (e.target === drawerOverlay) closeDrawer();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && drawerOverlay.classList.contains('active')) closeDrawer();
  });

  /* ---------- Preview rendering ---------- */
  const previewObserver = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const canvas = entry.target;
      previewObserver.unobserve(canvas);
      const file = previewTargets.get(canvas);
      if (file) renderPreview(canvas, file);
    }
  }, { rootMargin: '300px 0px' });

  async function renderPreview(canvas, file) {
    try {
      await loadLibs();
      const buffer = await file.arrayBuffer();
      const pdf = await window.pdfjsLib.getDocument({ data: buffer }).promise;
      const page = await pdf.getPage(1);
      const viewport = page.getViewport({ scale: CONFIG.previewScale });
      const outputScale = Math.min(window.devicePixelRatio || 1, 2);

      canvas.width  = Math.floor(viewport.width  * outputScale);
      canvas.height = Math.floor(viewport.height * outputScale);
      const ctx = canvas.getContext('2d');
      const transform = outputScale !== 1
        ? [outputScale, 0, 0, outputScale, 0, 0] : undefined;

      await page.render({ canvasContext: ctx, viewport, transform }).promise;
      pdf.destroy();
    } catch (_) {}
  }

  /* ---------- File intake ---------- */
  function addFiles(selected) {
    const rejected = { type: 0, size: 0, dup: 0 };
    const seen = new Set(
      files.map((f) => f.file.name + '|' + f.file.size + '|' + f.file.lastModified)
    );

    for (const f of selected) {
      const isPdf = f.type === 'application/pdf' || /\.pdf$/i.test(f.name);
      if (!isPdf) { rejected.type++; continue; }
      if (f.size > MAX_SIZE_BYTES) { rejected.size++; continue; }
      if (files.length >= CONFIG.maxFiles) { rejected.size++; continue; }

      const key = f.name + '|' + f.size + '|' + f.lastModified;
      if (seen.has(key)) { rejected.dup++; continue; }
      seen.add(key);

      files.push({ file: f, id: ++fileIdCounter });
    }

    if (rejected.type) {
      showNotice(rejected.type + ' non-PDF file' + (rejected.type > 1 ? 's' : '') + ' skipped.', 'warn');
    } else if (rejected.size) {
      showNotice('Some files skipped — over ' + CONFIG.maxSizeMB + ' MB or the ' + CONFIG.maxFiles + '-file limit.', 'warn');
    } else if (rejected.dup) {
      showNotice(rejected.dup + ' duplicate file' + (rejected.dup > 1 ? 's' : '') + ' skipped.', 'warn');
    }

    renderFiles();
  }

  /* ---------- File list ---------- */
  function renderFiles() {
    fileList.textContent = '';
    if (files.length === 0) {
      fileListHeader.hidden = true;
      processBtn.disabled = true;
      return;
    }

    const targetBytes = getTargetBytes();
    const frag = document.createDocumentFragment();

    files.forEach((entry, index) => {
      const card = document.createElement('div');
      card.className = 'file-card';

      const left = document.createElement('div');
      left.className = 'file-left';

      const preview = document.createElement('div');
      preview.className = 'file-preview';
      const canvas = document.createElement('canvas');
      preview.appendChild(canvas);
      previewTargets.set(canvas, entry.file);

      const info = document.createElement('div');
      info.className = 'file-info';

      const name = document.createElement('div');
      name.className = 'file-name';
      name.textContent = entry.file.name;

      const size = document.createElement('div');
      size.className = 'file-size';
      size.textContent = formatSize(entry.file.size);

      info.appendChild(name);
      info.appendChild(size);

      if (targetBytes > 0) {
        const badge = document.createElement('span');
        badge.className = 'file-target';
        if (entry.file.size <= targetBytes) {
          badge.classList.add('met');
          badge.innerHTML =
            '<i class="fas fa-check" aria-hidden="true"></i> Already under ' +
            formatTargetLabel(targetBytes);
        } else {
          badge.innerHTML =
            '<i class="fas fa-bullseye" aria-hidden="true"></i> Target: ' +
            formatTargetLabel(targetBytes);
        }
        info.appendChild(badge);
      }

      left.appendChild(preview);
      left.appendChild(info);

      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'remove-btn';
      remove.setAttribute('aria-label', 'Remove ' + entry.file.name);
      remove.innerHTML = '<i class="fas fa-trash" aria-hidden="true"></i>';
      remove.addEventListener('click', () => {
        files.splice(index, 1);
        renderFiles();
        syncTargetState();
      });

      card.appendChild(left);
      card.appendChild(remove);
      frag.appendChild(card);
      previewObserver.observe(canvas);
    });

    fileList.appendChild(frag);

    const totalSize = files.reduce((s, e) => s + e.file.size, 0);
    fileSummary.textContent =
      files.length + ' file' + (files.length > 1 ? 's' : '') + ' · ' + formatSize(totalSize);
    fileListHeader.hidden = false;
    processBtn.disabled = isProcessing;
  }

  clearAllBtn.addEventListener('click', () => {
    files = [];
    renderFiles();
    syncTargetState();
    results.textContent = '';
    progressArea.hidden = true;
    showNotice('Cleared all files.', null);
  });

  /* ---------- Upload interactions ---------- */
  uploadArea.addEventListener('click', () => fileInput.click());
  uploadArea.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault(); fileInput.click();
    }
  });
  fileInput.addEventListener('change', (e) => {
    if (e.target.files && e.target.files.length) {
      addFiles(Array.from(e.target.files));
      syncTargetState();
    }
    fileInput.value = '';
  });

  let dragDepth = 0;
  uploadArea.addEventListener('dragenter', (e) => {
    e.preventDefault(); dragDepth++; uploadArea.classList.add('dragover');
  });
  uploadArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
  });
  uploadArea.addEventListener('dragleave', () => {
    dragDepth = Math.max(0, dragDepth - 1);
    if (dragDepth === 0) uploadArea.classList.remove('dragover');
  });
  uploadArea.addEventListener('drop', (e) => {
    e.preventDefault();
    dragDepth = 0; uploadArea.classList.remove('dragover');
    const dropped = Array.from(e.dataTransfer.files || []).filter(
      (f) => f.type === 'application/pdf' || /\.pdf$/i.test(f.name)
    );
    if (dropped.length) { addFiles(dropped); syncTargetState(); }
    else showNotice('Please drop PDF files only.', 'warn');
  });
  ['dragover', 'drop'].forEach((evt) => {
    document.addEventListener(evt, (e) => {
      if (!uploadArea.contains(e.target)) e.preventDefault();
    });
  });

  /* ---------- Core rendering ---------- */
  async function renderPageToCanvas(pdf, pageNum, scale) {
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale });
    const canvas = document.createElement('canvas');
    canvas.width  = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const ctx = canvas.getContext('2d', { alpha: false });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    await page.render({ canvasContext: ctx, viewport }).promise;
    return canvas;
  }

  async function buildPdfFromCanvases(canvases, quality) {
    const newPdf = await window.PDFLib.PDFDocument.create();
    for (const canvas of canvases) {
      const blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', quality));
      const bytes = await blob.arrayBuffer();
      const jpg = await newPdf.embedJpg(bytes);
      const page = newPdf.addPage([jpg.width, jpg.height]);
      page.drawImage(jpg, { x: 0, y: 0, width: jpg.width, height: jpg.height });
      await new Promise((r) => setTimeout(r, 0));
    }
    const pdfBytes = await newPdf.save();
    return new Blob([pdfBytes], { type: 'application/pdf' });
  }

  /**
   * Target mode: search quality, then progressively lower resolution.
   * Returns { blob, quality, scale, reached }.
   */
  async function fitToTarget(pdf, numPages, targetBytes, baseScale, onPhase) {
    const { targetMinQuality: LO, targetMaxQuality: HI,
            targetMaxQualityIterations: MAX_ITER,
            targetQualityTolerance: TOL,
            targetScaleSteps: SCALES } = CONFIG;

    let bestAcrossScales = null;
    let bestQ = HI, bestScale = baseScale;

    for (let sIdx = 0; sIdx < SCALES.length; sIdx++) {
      const scale = baseScale * SCALES[sIdx];
      const isLast = sIdx === SCALES.length - 1;

      onPhase('render', sIdx);
      const canvases = [];
      try {
        for (let i = 1; i <= numPages; i++) {
          canvases.push(await renderPageToCanvas(pdf, i, scale));
          onPhase('render-progress', sIdx, i / numPages);
          if (i % CONFIG.yieldEveryPages === 0) await new Promise((r) => setTimeout(r, 0));
        }

        // Try HI first
        onPhase('quality', sIdx, 0, HI);
        let blob = await buildPdfFromCanvases(canvases, HI);
        if (!bestAcrossScales || blob.size < bestAcrossScales.size) {
          bestAcrossScales = blob; bestQ = HI; bestScale = scale;
        }
        if (blob.size <= targetBytes) {
          onPhase('done');
          return { blob, quality: HI, scale, reached: true };
        }

        // Try LO
        onPhase('quality', sIdx, 0.15, LO);
        blob = await buildPdfFromCanvases(canvases, LO);
        if (blob.size < bestAcrossScales.size) {
          bestAcrossScales = blob; bestQ = LO; bestScale = scale;
        }
        if (blob.size <= targetBytes) {
          // LO fits — binary search upward for best quality that still fits
          let best = blob, bestLocalQ = LO;
          let lo = LO, hi = HI, iter = 0;
          while (iter < MAX_ITER && (hi - lo) > TOL) {
            const mid = (lo + hi) / 2;
            onPhase('quality', sIdx, 0.15 + 0.85 * (iter / MAX_ITER), mid);
            const b = await buildPdfFromCanvases(canvases, mid);
            if (b.size <= targetBytes) {
              best = b; bestLocalQ = mid; lo = mid;
            } else { hi = mid; }
            iter++;
          }
          onPhase('done');
          return { blob: best, quality: bestLocalQ, scale, reached: true };
        }

        // LO didn't fit at this scale
        if (isLast) {
          onPhase('done');
          return {
            blob: bestAcrossScales,
            quality: bestQ,
            scale: bestScale,
            reached: false,
          };
        }
      } finally {
        canvases.forEach((c) => { c.width = 0; c.height = 0; });
      }
    }

    onPhase('done');
    return {
      blob: bestAcrossScales, quality: bestQ, scale: bestScale, reached: false,
    };
  }

  /**
   * Fixed-quality mode (no target set).
   */
  async function compressFixedQuality(file, quality, onProgress) {
    const buffer = await file.arrayBuffer();
    const pdf = await window.pdfjsLib.getDocument({ data: buffer }).promise;
    const numPages = pdf.numPages;
    try {
      const newPdf = await window.PDFLib.PDFDocument.create();
      for (let i = 1; i <= numPages; i++) {
        const canvas = await renderPageToCanvas(pdf, i, CONFIG.renderScale);
        const blob = await new Promise((r) => canvas.toBlob(r, 'image/jpeg', quality));
        const bytes = await blob.arrayBuffer();
        const jpg = await newPdf.embedJpg(bytes);
        const page = newPdf.addPage([jpg.width, jpg.height]);
        page.drawImage(jpg, { x: 0, y: 0, width: jpg.width, height: jpg.height });
        canvas.width = 0; canvas.height = 0;
        if (onProgress) onProgress(i / numPages);
        if (i % CONFIG.yieldEveryPages === 0) await new Promise((r) => setTimeout(r, 0));
      }
      const pdfBytes = await newPdf.save();
      return new Blob([pdfBytes], { type: 'application/pdf' });
    } finally {
      try { pdf.destroy(); } catch (_) {}
    }
  }

  /* ---------- Result rendering ---------- */
  function addResultCard(opts) {
    const { originalFile, blob, name, url, targetBytes,
            quality, scale, reached, usedOriginal, skipped, error } = opts;

    const card = document.createElement('div');
    card.className = 'result-card';

    if (error) {
      card.classList.add('result-error');
      const info = document.createElement('div');
      info.className = 'result-info';
      const title = document.createElement('strong');
      title.textContent = name;
      const meta = document.createElement('span');
      meta.className = 'result-meta';
      meta.textContent = 'Failed: ' + error;
      info.appendChild(title);
      info.appendChild(meta);
      card.appendChild(info);
    } else {
      const savedPct = originalFile.size > 0
        ? Math.round((1 - blob.size / originalFile.size) * 100) : 0;
      const savedLabel = savedPct > 0
        ? savedPct + '% smaller'
        : savedPct === 0 ? 'same size'
        : Math.abs(savedPct) + '% larger';

      const missedTarget = targetBytes > 0 && !usedOriginal && !reached && !skipped;
      if (missedTarget) card.classList.add('result-warn');

      const info = document.createElement('div');
      info.className = 'result-info';

      const title = document.createElement('strong');
      title.textContent = name;
      info.appendChild(title);

      if (targetBytes > 0) {
        const badge = document.createElement('span');
        let label;
        if (skipped) label = 'already under target';
        else if (usedOriginal) label = 'kept original';
        else if (reached) label = 'target met';
        else label = 'target not reached';
        badge.className = 'result-badge' + ((skipped || usedOriginal || reached) ? ' met' : '');
        badge.textContent = label;
        info.appendChild(badge);
      }

      const meta = document.createElement('span');
      meta.className = 'result-meta';
      const parts = [
        formatSize(originalFile.size) + ' → ' + formatSize(blob.size),
        savedLabel,
      ];
      if (!skipped && quality != null) parts.push('q' + Math.round(quality * 100));
      if (!skipped && scale != null && Math.abs(scale - CONFIG.renderScale) > 0.01) {
        parts.push('×' + scale.toFixed(2) + ' scale');
      }
      meta.textContent = parts.join(' · ');
      info.appendChild(meta);

      const link = document.createElement('a');
      link.className = 'download-btn';
      link.href = url;
      link.download = name;
      link.innerHTML = '<i class="fas fa-download" aria-hidden="true"></i> Download';

      card.appendChild(info);
      card.appendChild(link);
    }

    results.appendChild(card);
  }

  function addDownloadAllButton(downloads) {
    const card = document.createElement('div');
    card.className = 'result-card result-all';

    const info = document.createElement('div');
    info.className = 'result-info';
    const title = document.createElement('strong');
    title.textContent = downloads.length + ' compressed files ready';
    const meta = document.createElement('span');
    meta.className = 'result-meta';
    meta.textContent = 'Download each file individually, or grab them all at once.';
    info.appendChild(title);
    info.appendChild(meta);

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'download-btn';
    btn.innerHTML = '<i class="fas fa-download" aria-hidden="true"></i> Download all';
    btn.addEventListener('click', () => {
      downloads.forEach((d, i) => setTimeout(() => triggerDownload(d.url, d.name), i * 250));
    });
    card.appendChild(info);
    card.appendChild(btn);
    results.appendChild(card);
  }

  /* ---------- Progress ---------- */
  function setProgress(fraction, text) {
    const p = Math.max(0, Math.min(1, fraction));
    progressFill.style.width = (p * 100) + '%';
    progressBar.setAttribute('aria-valuenow', String(Math.round(p * 100)));
    if (text != null) progressText.textContent = text;
  }

  function resetProcessUI() {
    isProcessing = false;
    processBtn.disabled = files.length === 0;
    processBtnLabel.textContent = 'Compress PDFs';
    processBtnIcon.className = 'fas fa-bolt';
  }

  /* ---------- Main process ---------- */
  async function processAll() {
    if (isProcessing || files.length === 0) return;

    isProcessing = true;
    processBtn.disabled = true;
    processBtnLabel.textContent = 'Compressing…';
    processBtnIcon.className = 'fas fa-spinner fa-spin';
    results.textContent = '';
    progressArea.hidden = false;
    setProgress(0, 'Loading PDF engine…');

    try { await loadLibs(); }
    catch (err) {
      showNotice('Could not load the PDF engine. Check your connection and try again.', 'error');
      progressArea.hidden = true;
      resetProcessUI();
      return;
    }

    const quality = parseFloat(qualitySelect.value);
    const targetBytes = getTargetBytes();
    const total = files.length;
    const downloads = [];

    for (let i = 0; i < total; i++) {
      const entry = files[i];
      const originalFile = entry.file;
      const outName = originalFile.name.replace(/\.pdf$/i, '') + '-compressed.pdf';
      const fileBase = i / total;
      const fileSpan = 1 / total;

      // ---- Pre-skip: already under target ----
      if (targetBytes > 0 && originalFile.size <= targetBytes) {
        const url = URL.createObjectURL(originalFile);
        objectUrls.add(url);
        downloads.push({ url, name: originalFile.name });
        addResultCard({
          originalFile,
          blob: originalFile,
          name: originalFile.name,
          url,
          targetBytes,
          skipped: true,
        });
        setProgress(fileBase + fileSpan, 'Skipped ' + originalFile.name + ' (already under target)');
        await new Promise((r) => setTimeout(r, 0));
        continue;
      }

      // ---- Open the PDF ----
      let pdf;
      try {
        const buf = await originalFile.arrayBuffer();
        pdf = await window.pdfjsLib.getDocument({ data: buf }).promise;
      } catch (err) {
        addResultCard({
          originalFile, name: originalFile.name,
          error: 'Could not read PDF',
        });
        continue;
      }

      try {
        let blob, usedQuality = null, usedScale = null, reached = false;

        if (targetBytes > 0) {
          // Pixel-budget-aware base scale
          let baseScale = CONFIG.renderScale;
          try {
            const first = await pdf.getPage(1);
            const vp = first.getViewport({ scale: 1 });
            const pxPerPage = vp.width * vp.height;
            const est = pxPerPage * pdf.numPages * baseScale * baseScale;
            if (est > CONFIG.canvasPixelBudget) {
              baseScale = Math.max(
                0.6,
                Math.sqrt(CONFIG.canvasPixelBudget / (pxPerPage * pdf.numPages))
              );
            }
          } catch (_) {}

          const attemptCount = CONFIG.targetScaleSteps.length;
          const onPhase = (phase, sIdx, p, q) => {
            const attemptSize = fileSpan / attemptCount;
            const attemptBase = fileBase + (sIdx || 0) * attemptSize;
            const passLabel = ' (pass ' + ((sIdx || 0) + 1) + '/' + attemptCount + ')';

            if (phase === 'render') {
              setProgress(attemptBase, 'Rendering pages' + passLabel + '…');
            } else if (phase === 'render-progress') {
              setProgress(attemptBase + attemptSize * 0.4 * p, 'Rendering pages' + passLabel + '…');
            } else if (phase === 'quality') {
              setProgress(
                attemptBase + attemptSize * (0.4 + 0.6 * (p || 0)),
                'Trying quality ' + Math.round((q || 0.7) * 100) + '%' + passLabel + '…'
              );
            }
          };

          const result = await fitToTarget(pdf, pdf.numPages, targetBytes, baseScale, onPhase);
          blob = result.blob;
          usedQuality = result.quality;
          usedScale = result.scale;
          reached = result.reached;
        } else {
          blob = await compressFixedQuality(originalFile, quality, (p) => {
            setProgress(fileBase + fileSpan * p,
              'Compressing ' + originalFile.name + '…');
          });
        }

        // Keep smaller file when a target was requested
        let usedOriginal = false;
        if (targetBytes > 0 && blob.size >= originalFile.size) {
          blob = originalFile;
          usedOriginal = true;
        }

        const url = URL.createObjectURL(blob);
        objectUrls.add(url);
        downloads.push({ url, name: outName });

        addResultCard({
          originalFile, blob, name: outName, url,
          targetBytes, quality: usedQuality, scale: usedScale, reached, usedOriginal,
        });
      } catch (err) {
        console.error(err);
        addResultCard({
          originalFile, name: originalFile.name,
          error: err.message || 'Unknown error',
        });
      } finally {
        try { pdf.destroy(); } catch (_) {}
      }

      await new Promise((r) => setTimeout(r, 0));
    }

    setProgress(1, 'Done!');
    if (downloads.length > 1) addDownloadAllButton(downloads);

    setTimeout(() => {
      progressArea.hidden = true;
      resetProcessUI();
    }, 1500);
  }

  processBtn.addEventListener('click', processAll);

  /* ---------- Cleanup ---------- */
  window.addEventListener('beforeunload', () => {
    objectUrls.forEach((u) => URL.revokeObjectURL(u));
    objectUrls.clear();
  });

  /* ---------- Init ---------- */
  syncTargetState();

})();