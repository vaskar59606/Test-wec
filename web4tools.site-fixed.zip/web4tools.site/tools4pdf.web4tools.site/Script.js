/* ============================================================
   Tools4Pdf — homepage interactions
   • App drawer toggle (identical behavior to original)
   • Tool category filtering
   • ESC key + backdrop click to close
   ============================================================ */

(function () {
  'use strict';

  /* ---------- App drawer ---------- */
  const drawerBtn     = document.getElementById('appDrawerBtn');
  const overlay       = document.getElementById('drawerOverlay');
  const closeDrawerBtn = document.getElementById('closeDrawerBtn');

  function openDrawer() {
    overlay.classList.add('active');
    drawerBtn.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
    // Move focus into the dialog for accessibility
    setTimeout(() => closeDrawerBtn.focus(), 200);
  }

  function closeDrawer() {
    overlay.classList.remove('active');
    drawerBtn.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
    drawerBtn.focus();
  }

  drawerBtn?.addEventListener('click', openDrawer);
  closeDrawerBtn?.addEventListener('click', closeDrawer);
  overlay?.addEventListener('click', (e) => {
    if (e.target === overlay) closeDrawer();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && overlay.classList.contains('active')) closeDrawer();
  });

  /* ---------- Tool filtering ---------- */
  const filterTags = document.querySelectorAll('.filter-tag');
  const toolCards  = document.querySelectorAll('.tool-card');

  function filterTools(category) {
    toolCards.forEach((card) => {
      const cardCat = card.getAttribute('data-cat');
      if (category === 'all' || cardCat === category) {
        card.classList.remove('hidden-card');
      } else {
        card.classList.add('hidden-card');
      }
    });

    filterTags.forEach((tag) => {
      const isActive = tag.getAttribute('data-filter') === category;
      tag.classList.toggle('active', isActive);
      tag.setAttribute('aria-selected', isActive ? 'true' : 'false');
    });
  }

  filterTags.forEach((tag) => {
    tag.addEventListener('click', () => {
      const filterValue = tag.getAttribute('data-filter');
      filterTools(filterValue);
    });
  });

  /* ---------- Keyboard nav for filter tabs ---------- */
  const filterBar = document.getElementById('filterBar');
  if (filterBar) {
    filterBar.addEventListener('keydown', (e) => {
      const tabs = Array.from(filterTags);
      const currentIndex = tabs.indexOf(document.activeElement);
      if (currentIndex === -1) return;

      let nextIndex = currentIndex;
      if (e.key === 'ArrowRight') nextIndex = (currentIndex + 1) % tabs.length;
      else if (e.key === 'ArrowLeft') nextIndex = (currentIndex - 1 + tabs.length) % tabs.length;
      else if (e.key === 'Home') nextIndex = 0;
      else if (e.key === 'End') nextIndex = tabs.length - 1;
      else return;

      e.preventDefault();
      tabs[nextIndex].focus();
      tabs[nextIndex].click();
    });
  }

})();